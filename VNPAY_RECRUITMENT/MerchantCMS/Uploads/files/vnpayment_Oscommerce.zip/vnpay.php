﻿<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of vnpay
 *
 * @author khoakd@vnpay.vn
 */
class vnpay {

    var $code, $title, $description, $enabled, $form_action_url, $merchantid, $secretkey, $accesscode, $url_vnpay, $url_return, $curr_code, $ajaxurl;

    function vnpay() {
        global $order;

        $this->code = 'vnpay';
        $this->title = "VNPAYMENT";
        $this->description = "VNPAYMENT";
        $this->merchantid = defined('MODULE_PAYMENT_VNPAY_MERCHANT') ? MODULE_PAYMENT_VNPAY_MERCHANT : '';
        $this->enabled = defined('MODULE_PAYMENT_VNPAY_MERCHANT') && (MODULE_PAYMENT_VNPAY_MERCHANT != null) ? true : false;
        $this->accesscode = defined('MODULE_PAYMENT_VNPAY_ACCESSCODE') ? MODULE_PAYMENT_VNPAY_ACCESSCODE : "";
        $this->secretkey = defined('MODULE_PAYMENT_VNPAY_SECRETKEY') ? MODULE_PAYMENT_VNPAY_SECRETKEY : "";
        $this->url_vnpay = defined('MODULE_PAYMENT_VNPAY_URL_VNPAY') ? MODULE_PAYMENT_VNPAY_URL_VNPAY : "";
        $this->url_return = defined('MODULE_PAYMENT_VNPAY_URL_RETURN') ? MODULE_PAYMENT_VNPAY_URL_RETURN : "";
        //$this->form_action_url = "http://google.com";
        $this->ajaxurl = "";
        if ($this->enabled === true) {
            if (isset($order) && is_object($order)) {
                $this->update_status();
            }
        }
    }

    private $log_file, $fp, $amount;

    // set log file (path and name)
    public function lfile($path) {

        $this->log_file = $path;
    }

    // write message to the log file
    public function lwrite($message) {
        // if file pointer doesn't exist, then open log file
        if (!is_resource($this->fp)) {
            $this->lopen();
        }
        // define script name
        $script_name = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME);
        // define current time and suppress E_WARNING if using the system TZ settings
        // (don't forget to set the INI setting date.timezone)
        $time = @date('[d/M/Y:H:i:s]');
        // write current time, script name and message to the log file
        fwrite($this->fp, "$time ($script_name) $message" . PHP_EOL);
    }

    // close log file (it's always a good idea to close a file when you're done with it)
    public function lclose() {
        fclose($this->fp);
    }

    // open log file (private method)
    private function lopen() {
        // in case of Windows set default log file
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $log_file_default = 'D:/logs/vnpaylogs/vnplog.txt';
        }
        // set default log file for Linux and other systems
        else {
            $log_file_default = 'D:/logs/vnpaylogs/vnplog.txt';
        }
        // define log file from lfile method or use previously set default
        $lfile = $this->log_file ? $this->log_file : $log_file_default;
        // open log file for writing only and place file pointer at the end of the file
        // (if the file does not exist, try to create it)
        $this->fp = fopen($lfile, 'a') or exit("Can't open $lfile!");
    }

    function update_status() {
        global $order;

        if (($this->enabled == true) && ((int) MODULE_PAYMENT_COD_ZONE > 0)) {
            $check_flag = false;
            $check_query = tep_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_COD_ZONE . "' and zone_country_id = '" . $order->delivery['country']['id'] . "' order by zone_id");
            while ($check = tep_db_fetch_array($check_query)) {
                if ($check['zone_id'] < 1) {
                    $check_flag = true;
                    break;
                } elseif ($check['zone_id'] == $order->delivery['zone_id']) {
                    $check_flag = true;
                    break;
                }
            }

            if ($check_flag == false) {
                $this->enabled = false;
            }
        }

// disable the module if the order only contains virtual products
        if ($this->enabled == true) {
            if ($order->content_type == 'virtual') {
                $this->enabled = false;
            }
        }
    }

    function javascript_validation() {
        return false;
    }

    function selection() {
        return array('id' => $this->code,
            'module' => $this->title);
    }

    function add_vnpay_js() {
        global $order, $orderid, $customer_id;
        $q = tep_db_query("select max(orders_id)as orders_id from orders where customers_id='" . $customer_id . "'");
        if ($result = mysqli_fetch_array($q)) {
            $orderid = $result['orders_id'];
        }
        $items_total = $this->format_raw($order->info['total']);
        $date = new DateTime(); //this returns the current date time
        $result = $date->format('Y-m-d-H-i-s');
        $today = date("Y-m-d H:i:s");
        $krr = explode('-', $result);
        $result1 = implode("", $krr);
        $total_amount = $items_total;
        $vnp_Url = $this->url_vnpay;
        $vnp_Returnurl = $this->url_return; // trả về link của mình
        //$hashSecret = '';
        $vnp_Locale = "vn";
        $vnp_OrderInfo = 'Thanh toán từ oscommer đơn hàng' . ' Luc :' . $today;
        $vnp_OrderType = "billpayment";
        //$vnp_Merchant = '';
        $vnp_CurrCode = "VND";
        //$vnp_AccessCode = '';
        $vnp_Amount = $total_amount * 100;
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
        $vnp_Merchant = $this->merchantid;
        $hashSecret = $this->secretkey;
        $vnp_AccessCode = $this->accesscode;
        $Odarray = array(
            "vnp_AccessCode" => $vnp_AccessCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => $result1,
            "vnp_CurrCode" => $vnp_CurrCode,
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_Merchant" => $vnp_Merchant,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $orderid,
            "vnp_Version" => "1",
        );
        ksort($Odarray);
        $query = "";
        $i = 0;
        $data = "";
        foreach ($Odarray as $key => $value) {
            if ($i == 1) {
                $data .= '&' . $key . "=" . $value;
            } else {
                $data .= $key . "=" . $value;
                $i = 1;
            }

            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }
		$vnp_Url.='?';
        $vnp_Url .=$query;
        if (isset($hashSecret)) {
            $vnpSecureHash = md5($hashSecret . $data);
            $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
            $this->lwrite('========================================================');
            $this->lwrite('HashData=' . $hashSecret . $data);
            $this->lwrite('SecureHash=' . $vnpSecureHash);
            $this->lwrite('RedirectUrl=' . $vnp_Url);
            $this->lwrite('========================================================');
        }
        //echo($vnp_Url);
        $js = <<<EOD

        <link href="https://pay.vnpay.vn/lib/vnpbox/vnpbox.css" rel="stylesheet" />
        <script src="https://pay.vnpay.vn/lib/vnpbox/jquery.vnpbox.js"></script>
        <script type="text/javascript">
              $('form[name="checkout_confirmation"]').attr('id', 'payment-form');
              $(document).ready(function(){
                  //$('form[name="checkout_confirmation"]').submit(function(){
                        jQuery.colorbox({
                                iframe: true,
                                innerWidth: 350,
                                innerHeight: 500, overlayClose: false, scrolling: false,
                                href: "$vnp_Url",
                                onComplete: function () {
                                    var clrobj = $(this).colorbox;
                                    var w = 352;
                                    // Here "addEventListener" is for standards-compliant web browsers and "attachEvent" is for IE Browsers.
                                    var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
                                    var eventer = window[eventMethod];
                                    var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
                                    // Listen to message from child IFrame window
                                    eventer(messageEvent, function (e) {
                                        console.log("e.data = " + e.data);
                                        clrobj.resize({
                                            "height": e.data,
                                            "width": w
                                        });
                                        // Do whatever you want to do with the data got from IFrame in Parent form.
                                    }, false);
                                }
                            });
                  return false;                   
                  // });
               });    
        </script>
EOD;

        return $js;
    }

    function templateClassExists() {
        return class_exists('oscTemplate') && isset($GLOBALS['oscTemplate']) && is_object($GLOBALS['oscTemplate']) && (get_class($GLOBALS['oscTemplate']) == 'oscTemplate');
    }

    function pre_confirmation_check() {
        global $cartID, $cart;
        global $cartID, $customer_id, $languages_id, $order, $order_total_modules, $order_totals;
        //$order_totals = $order_total_modules->process();

        if (empty($cart->cartID)) {
            $cartID = $cart->cartID = $cart->generate_cart_id();
        }

        if (!tep_session_is_registered('cartID')) {
            tep_session_register('cartID');
        }
        return false;
    }

    function confirmation() {

        if (file_exists('/logs/vnpaylogs/vnplog.txt')) {
            $this->lfile('/logs/vnpaylogs/vnplog.txt');
        } else {
            mkdir('/logs/vnpaylogs/', 0777, true);
            touch('/logs/vnpaylogs/vnplog.txt');
            $this->lfile('/logs/vnpaydemophp/vnplog.txt');
        }

        global $cartID, $cart_vnpay_Standard_ID, $customer_id, $languages_id, $order, $order_total_modules;

        if (tep_session_is_registered('cartID')) {
            $insert_order = false;

            if (tep_session_is_registered('cart_inpay_Standard_ID')) {
                $order_id = substr($cart_vnpay_Standard_ID, strpos($cart_vnpay_Standard_ID, '-') + 1);

                $curr_check = tep_db_query("select currency from " . TABLE_ORDERS . " where orders_id = '" . (int) $order_id . "'");
                $curr = tep_db_fetch_array($curr_check);

                if (($curr['currency'] != $order->info['currency']) || ($cartID != substr($cart_vnpay_Standard_ID, 0, strlen($cartID)))) {
                    $check_query = tep_db_query('select orders_id from ' . TABLE_ORDERS_STATUS_HISTORY . ' where orders_id = "' . (int) $order_id . '" limit 1');

                    if (tep_db_num_rows($check_query) < 1) {
                        tep_db_query('delete from ' . TABLE_ORDERS . ' where orders_id = "' . (int) $order_id . '"');
                        tep_db_query('delete from ' . TABLE_ORDERS_TOTAL . ' where orders_id = "' . (int) $order_id . '"');
                        tep_db_query('delete from ' . TABLE_ORDERS_STATUS_HISTORY . ' where orders_id = "' . (int) $order_id . '"');
                        tep_db_query('delete from ' . TABLE_ORDERS_PRODUCTS . ' where orders_id = "' . (int) $order_id . '"');
                        tep_db_query('delete from ' . TABLE_ORDERS_PRODUCTS_ATTRIBUTES . ' where orders_id = "' . (int) $order_id . '"');
                        tep_db_query('delete from ' . TABLE_ORDERS_PRODUCTS_DOWNLOAD . ' where orders_id = "' . (int) $order_id . '"');
                    }

                    $insert_order = true;
                }
            } else {
                $insert_order = true;
            }

            if ($insert_order == true) {
                $order_totals = array();
                if (is_array($order_total_modules->modules)) {
                    reset($order_total_modules->modules);
                    while (list (, $value) = each($order_total_modules->modules)) {
                        $class = substr($value, 0, strrpos($value, '.'));
                        if ($GLOBALS[$class]->enabled) {
                            for ($i = 0, $n = sizeof($GLOBALS[$class]->output); $i < $n; $i++) {
                                if (tep_not_null($GLOBALS[$class]->output[$i]['title']) && tep_not_null($GLOBALS[$class]->output[$i]['text'])) {
                                    $order_totals[] = array('code' => $GLOBALS[$class]->code,
                                        'title' => $GLOBALS[$class]->output[$i]['title'],
                                        'text' => $GLOBALS[$class]->output[$i]['text'],
                                        'value' => $GLOBALS[$class]->output[$i]['value'],
                                        'sort_order' => $GLOBALS[$class]->sort_order);
                                }
                            }
                        }
                    }
                }

                $sql_data_array = array('customers_id' => $customer_id,
                    'customers_name' => $order->customer['firstname'] . ' ' . $order->customer['lastname'],
                    'customers_company' => $order->customer['company'],
                    'customers_street_address' => $order->customer['street_address'],
                    'customers_suburb' => $order->customer['suburb'],
                    'customers_city' => $order->customer['city'],
                    'customers_postcode' => $order->customer['postcode'],
                    'customers_state' => $order->customer['state'],
                    'customers_country' => $order->customer['country']['title'],
                    'customers_telephone' => $order->customer['telephone'],
                    'customers_email_address' => $order->customer['email_address'],
                    'customers_address_format_id' => $order->customer['format_id'],
                    'delivery_name' => $order->delivery['firstname'] . ' ' . $order->delivery['lastname'],
                    'delivery_company' => $order->delivery['company'],
                    'delivery_street_address' => $order->delivery['street_address'],
                    'delivery_suburb' => $order->delivery['suburb'],
                    'delivery_city' => $order->delivery['city'],
                    'delivery_postcode' => $order->delivery['postcode'],
                    'delivery_state' => $order->delivery['state'],
                    'delivery_country' => $order->delivery['country']['title'],
                    'delivery_address_format_id' => $order->delivery['format_id'],
                    'billing_name' => $order->billing['firstname'] . ' ' . $order->billing['lastname'],
                    'billing_company' => $order->billing['company'],
                    'billing_street_address' => $order->billing['street_address'],
                    'billing_suburb' => $order->billing['suburb'],
                    'billing_city' => $order->billing['city'],
                    'billing_postcode' => $order->billing['postcode'],
                    'billing_state' => $order->billing['state'],
                    'billing_country' => $order->billing['country']['title'],
                    'billing_address_format_id' => $order->billing['format_id'],
                    'payment_method' => $order->info['payment_method'],
                    'cc_type' => $order->info['cc_type'],
                    'cc_owner' => $order->info['cc_owner'],
                    'cc_number' => $order->info['cc_number'],
                    'cc_expires' => $order->info['cc_expires'],
                    'date_purchased' => 'now()',
                    'orders_status' => $order->info['order_status'],
                    'currency' => $order->info['currency'],
                    'currency_value' => $order->info['currency_value']);

                tep_db_perform(TABLE_ORDERS, $sql_data_array);

                $insert_id = tep_db_insert_id();

                for ($i = 0, $n = sizeof($order_totals); $i < $n; $i++) {
                    $sql_data_array = array('orders_id' => $insert_id,
                        'title' => $order_totals[$i]['title'],
                        'text' => $order_totals[$i]['text'],
                        'value' => $order_totals[$i]['value'],
                        'class' => $order_totals[$i]['code'],
                        'sort_order' => $order_totals[$i]['sort_order']);

                    tep_db_perform(TABLE_ORDERS_TOTAL, $sql_data_array);
                }
                $customer_notification = (SEND_EMAILS == 'true') ? '1' : '0';
                
                $sql_data_array = array('orders_id' => $insert_id,
                    'orders_status_id' => $order->info['order_status'],
                    'date_added' => 'now()',
                    'customer_notified' => $customer_notification,
                    'comments' => $order->info['comments']);
                tep_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
                
                for ($i = 0, $n = sizeof($order->products); $i < $n; $i++) {
                    $sql_data_array = array('orders_id' => $insert_id,
                        'products_id' => tep_get_prid($order->products[$i]['id']),
                        'products_model' => $order->products[$i]['model'],
                        'products_name' => $order->products[$i]['name'],
                        'products_price' => $order->products[$i]['price'],
                        'final_price' => $order->products[$i]['final_price'],
                        'products_tax' => $order->products[$i]['tax'],
                        'products_quantity' => $order->products[$i]['qty']);

                    tep_db_perform(TABLE_ORDERS_PRODUCTS, $sql_data_array);

                    $order_products_id = tep_db_insert_id();

                    $attributes_exist = '0';
                    if (isset($order->products[$i]['attributes'])) {
                        $attributes_exist = '1';
                        for ($j = 0, $n2 = sizeof($order->products[$i]['attributes']); $j < $n2; $j++) {
                            if (DOWNLOAD_ENABLED == 'true') {
                                $attributes_query = "select popt.products_options_name, poval.products_options_values_name, pa.options_values_price, pa.price_prefix, pad.products_attributes_maxdays, pad.products_attributes_maxcount , pad.products_attributes_filename
                                       from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " . TABLE_PRODUCTS_ATTRIBUTES . " pa
                                       left join " . TABLE_PRODUCTS_ATTRIBUTES_DOWNLOAD . " pad
                                       on pa.products_attributes_id=pad.products_attributes_id
                                       where pa.products_id = '" . $order->products[$i]['id'] . "'
                                       and pa.options_id = '" . $order->products[$i]['attributes'][$j]['option_id'] . "'
                                       and pa.options_id = popt.products_options_id
                                       and pa.options_values_id = '" . $order->products[$i]['attributes'][$j]['value_id'] . "'
                                       and pa.options_values_id = poval.products_options_values_id
                                       and popt.language_id = '" . $languages_id . "'
                                       and poval.language_id = '" . $languages_id . "'";
                                $attributes = tep_db_query($attributes_query);
                            } else {
                                $attributes = tep_db_query("select popt.products_options_name, poval.products_options_values_name, pa.options_values_price, pa.price_prefix from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " . TABLE_PRODUCTS_ATTRIBUTES . " pa where pa.products_id = '" . $order->products[$i]['id'] . "' and pa.options_id = '" . $order->products[$i]['attributes'][$j]['option_id'] . "' and pa.options_id = popt.products_options_id and pa.options_values_id = '" . $order->products[$i]['attributes'][$j]['value_id'] . "' and pa.options_values_id = poval.products_options_values_id and popt.language_id = '" . $languages_id . "' and poval.language_id = '" . $languages_id . "'");
                            }
                            $attributes_values = tep_db_fetch_array($attributes);

                            $sql_data_array = array('orders_id' => $insert_id,
                                'orders_products_id' => $order_products_id,
                                'products_options' => $attributes_values['products_options_name'],
                                'products_options_values' => $attributes_values['products_options_values_name'],
                                'options_values_price' => $attributes_values['options_values_price'],
                                'price_prefix' => $attributes_values['price_prefix']);

                            tep_db_perform(TABLE_ORDERS_PRODUCTS_ATTRIBUTES, $sql_data_array);

                            if ((DOWNLOAD_ENABLED == 'true') && isset($attributes_values['products_attributes_filename']) && tep_not_null($attributes_values['products_attributes_filename'])) {
                                $sql_data_array = array('orders_id' => $insert_id,
                                    'orders_products_id' => $order_products_id,
                                    'orders_products_filename' => $attributes_values['products_attributes_filename'],
                                    'download_maxdays' => $attributes_values['products_attributes_maxdays'],
                                    'download_count' => $attributes_values['products_attributes_maxcount']);

                                tep_db_perform(TABLE_ORDERS_PRODUCTS_DOWNLOAD, $sql_data_array);
                            }
                        }
                    }
                }

                $cart_vnpay_Standard_ID = $cartID . '-' . $insert_id;
                tep_session_register('$cart_vnpay_Standard_ID');
            }
        }

        return false;
    }

    function process_button() {
        global $order, $orderid, $customer_id;
        $q = tep_db_query("select max(orders_id)as orders_id from orders where customers_id='" . $customer_id . "'");
        if ($result = mysqli_fetch_array($q)) {
            $orderid = $result['orders_id'];
        }
        $items_total = $this->format_raw($order->info['total']);
        $date = new DateTime(); //this returns the current date time
        $result = $date->format('Y-m-d-H-i-s');
        $today = date("Y-m-d H:i:s");
        $krr = explode('-', $result);
        $result1 = implode("", $krr);
        $total_amount = $items_total;
        $vnp_Url = $this->url_vnpay;
        $vnp_Returnurl = $this->url_return; // trả về link của mình
        //$hashSecret = '';
        $vnp_Locale = "vn";
        $vnp_OrderInfo = 'Thanh toán từ oscommer đơn hàng' . ' Luc :' . $today;
        $vnp_OrderType = "billpayment";
        //$vnp_Merchant = '';
        $vnp_CurrCode = "VND";
        //$vnp_AccessCode = '';
        $vnp_Amount = $total_amount * 100;
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
        $vnp_Merchant = $this->merchantid;
        $hashSecret = $this->secretkey;
        $vnp_AccessCode = $this->accesscode;
        $Odarray = array(
            "vnp_AccessCode" => $vnp_AccessCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => $result1,
            "vnp_CurrCode" => $vnp_CurrCode,
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_Merchant" => $vnp_Merchant,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $orderid,
            "vnp_Version" => "1",
        );
        ksort($Odarray);
        $query = "";
        $i = 0;
        $data = "";
        foreach ($Odarray as $key => $value) {
            if ($i == 1) {
                $data .= '&' . $key . "=" . $value;
            } else {
                $data .= $key . "=" . $value;
                $i = 1;
            }

            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }

        $vnp_Url .=$query;
        if (isset($hashSecret)) {
            $vnpSecureHash = md5($hashSecret . $data);
            $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
            $this->lwrite('========================================================');
            $this->lwrite('HashData=' . $hashSecret . $data);
            $this->lwrite('SecureHash=' . $vnpSecureHash);
            $this->lwrite('RedirectUrl=' . $vnp_Url);
            $this->lwrite('========================================================');
        }
        $js = <<<EOD

        <link href="https://pay.vnpay.vn/lib/vnpbox/vnpbox.css" rel="stylesheet" />
        <script src="https://pay.vnpay.vn/lib/vnpbox/jquery.vnpbox.js"></script>
        <script type="text/javascript">
              $(document).ready(function(){
             jQuery.colorbox({
                                iframe: true,
                                innerWidth: 350,
                                innerHeight: 500, overlayClose: false, scrolling: false,
                                href: "$vnp_Url",
                                onComplete: function () {
                                    var clrobj = $(this).colorbox;
                                    var w = 352;
                                    // Here "addEventListener" is for standards-compliant web browsers and "attachEvent" is for IE Browsers.
                                    var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
                                    var eventer = window[eventMethod];
                                    var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
                                    // Listen to message from child IFrame window
                                    eventer(messageEvent, function (e) {
                                        console.log("e.data = " + e.data);
                                        clrobj.resize({
                                            "height": e.data,
                                            "width": w
                                        });
                                        // Do whatever you want to do with the data got from IFrame in Parent form.
                                    }, false);
                                }
                            });
             return false;
                  });
        </script>
EOD;

        return $js;
    }

    function before_process() {
        $this->after_process();
        return false;
    }

    function after_process() {
        $this->goOut();
//        $this->lwrite('after_process');
//        global $HTTP_POST_VARS, $order, $order_totals, $sendto, $response_array;
//        $this->lwrite('before_process');
//        if ($this->templateClassExists()) {
//            $GLOBALS['oscTemplate']->addBlock($this->add_vnpay_js(), 'header_tags');
//        }
//        $item_params = array();
//
//        $line_item_no = 0;
//
//        foreach ($order->products as $product) {
//            $item_params['L_NAME' . $line_item_no] = $product['name'];
//            $item_params['L_AMT' . $line_item_no] = $this->format_raw($product['final_price']);
//            $item_params['L_NUMBER' . $line_item_no] = $product['id'];
//            $item_params['L_QTY' . $line_item_no] = $product['qty'];
//
//            $line_item_no++;
//        }
//
//        $items_total = $this->format_raw($order->info['subtotal']);
//
//        foreach ($order_totals as $ot) {
//            //$this->lwrite(var_dump($order_totals));
//            if (!in_array($ot['code'], array('ot_subtotal', 'ot_shipping', 'ot_tax', 'ot_total'))) {
//                $item_params['L_NAME' . $line_item_no] = $ot['title'];
//                $item_params['L_AMT' . $line_item_no] = $this->format_raw($ot['value']);
//
//                $items_total += $this->format_raw($ot['value']);
//
//                $line_item_no++;
//            }
//        }
//        $this->amount = $items_total;
//        //$this->lwrite('Tổng tiền : $items_total');
//        global $order, $orderid, $customer_id;
//        $q = tep_db_query("select max(orders_id)as orders_id from orders where customers_id='" . $customer_id . "'");
//        if ($result = mysqli_fetch_array($q)) {
//            $orderid = $result['orders_id'];
//        }
//
//        $date = new DateTime(); //this returns the current date time
//        $result = $date->format('Y-m-d-H-i-s');
//        $today = date("Y-m-d H:i:s");
//        $krr = explode('-', $result);
//        $result1 = implode("", $krr);
//        $total_amount = $this->amount;
//        $vnp_Url = $this->url_vnpay;
//        $hashSecret = $this->secretkey;
//        $vnp_Returnurl = $this->url_return; // trả về link của mình
//        //$hashSecret = '';
//        $vnp_Locale = "vn";
//        $vnp_OrderInfo = 'Thanh toán từ oscommer đơn hàng' . ' Luc :' . $today;
//        $vnp_OrderType = "billpayment";
//        //$vnp_Merchant = '';
//        $vnp_CurrCode = "VND";
//        //$vnp_AccessCode = '';
//        $vnp_Amount = $total_amount * 100;
//        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
//        $vnp_Merchant = $this->merchantid;
//
//        $vnp_AccessCode = $this->accesscode;
//
//        $Odarray = array(
//            "vnp_AccessCode" => $vnp_AccessCode,
//            "vnp_Amount" => $vnp_Amount,
//            "vnp_Command" => "pay",
//            "vnp_CreateDate" => $result1,
//            "vnp_CurrCode" => $vnp_CurrCode,
//            "vnp_IpAddr" => $vnp_IpAddr,
//            "vnp_Locale" => $vnp_Locale,
//            "vnp_Merchant" => $vnp_Merchant,
//            "vnp_OrderInfo" => $vnp_OrderInfo,
//            "vnp_OrderType" => $vnp_OrderType,
//            "vnp_ReturnUrl" => $vnp_Returnurl,
//            "vnp_TxnRef" => $orderid,
//            "vnp_Version" => "1",
//        );
//        ksort($Odarray);
//        $query = "";
//        $i = 0;
//        $data = "";
//        foreach ($Odarray as $key => $value) {
//            if ($i == 1) {
//                $data .= '&' . $key . "=" . $value;
//            } else {
//                $data .= $key . "=" . $value;
//                $i = 1;
//            }
//
//            $query .= urlencode($key) . "=" . urlencode($value) . '&';
//        }
//
//        $vnp_Url .=$query;
//        if (isset($hashSecret)) {
//            $vnpSecureHash = md5($hashSecret . $data);
//            $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
//            $this->lwrite('========================================================');
//            $this->lwrite('HashData=' . $hashSecret . $data);
//            $this->lwrite('SecureHash=' . $vnpSecureHash);
//            $this->lwrite('RedirectUrl=' . $vnp_Url);
//            $this->lwrite('========================================================');
//        }
//        // tep_session_register('vnpSecureHash', $vnpSecureHash);
//        //$_SESSION['secretkey'] = $this->secretkey;
//        //tep_session_register(vnpSecureHash);
//        tep_redirect($vnp_Url);
        return false;
    }

    function get_error() {
        return false;
    }

    function check() {
        if (!isset($this->_check)) {
            $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_COD_STATUS'");
            $this->_check = tep_db_num_rows($check_query);
        }
        return $this->_check;
    }

    function install() {
        tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('MERCHANTID', 'MODULE_PAYMENT_VNPAY_MERCHANT', '', 'Merchant Id', '250', '1', '', now())");
        tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('SECRETKEY', 'MODULE_PAYMENT_VNPAY_SECRETKEY', '', 'The SECRETKEY', '255', '2', now())");
        tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('ACCESSCODE', 'MODULE_PAYMENT_VNPAY_ACCESSCODE', '', 'The ACCESSCODE to vnpayment', '8', '8', now())");
        tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('URL_VNPAY', 'MODULE_PAYMENT_VNPAY_URL_VNPAY', '', 'The URL_VNPAY', '1000', '4', now())");
        tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('URL_RETURN', 'MODULE_PAYMENT_VNPAY_URL_RETURN', '', 'The URL_RETURN', '1000', '4', '', now())");
        tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('CURRCODE', 'MODULE_PAYMENT_VNPAY_CURRCODE', '', 'The CURRCODE', '3', '3', now())");
    }

    function remove() {
        tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
//return array('MODULE_PAYMENT_COD_STATUS', 'MODULE_PAYMENT_COD_ZONE', 'MODULE_PAYMENT_COD_ORDER_STATUS_ID', 'MODULE_PAYMENT_COD_SORT_ORDER');
        $keys = array_keys($this->getParams());

        if ($this->check()) {
            foreach ($keys as $key) {
                if (!defined($key)) {
                    $this->install($key);
                }
            }
        }
        return array('MODULE_PAYMENT_VNPAY_MERCHANT', 'MODULE_PAYMENT_VNPAY_SECRETKEY', 'MODULE_PAYMENT_VNPAY_ACCESSCODE', 'MODULE_PAYMENT_VNPAY_URL_VNPAY', 'MODULE_PAYMENT_VNPAY_URL_RETURN', 'MODULE_PAYMENT_VNPAY_CURRCODE');
    }

    function getParams() {
        return array('MODULE_PAYMENT_VNPAY_MERCHANT', 'MODULE_PAYMENT_VNPAY_SECRETKEY', 'MODULE_PAYMENT_VNPAY_ACCESSCODE', 'MODULE_PAYMENT_VNPAY_URL_VNPAY', 'MODULE_PAYMENT_VNPAY_URL_RETURN', 'MODULE_PAYMENT_VNPAY_CURRCODE');
    }

    function format_raw($number, $currency_code = '', $currency_value = '') {
        global $currencies, $currency;

        if (empty($currency_code) || !$this->is_set($currency_code)) {
            $currency_code = $currency;
        }

        if (empty($currency_value) || !is_numeric($currency_value)) {
            $currency_value = $currencies->currencies[$currency_code]['value'];
        }

        return number_format(tep_round($number * $currency_value, $currencies->currencies[$currency_code]['decimal_places']), $currencies->currencies[$currency_code]['decimal_places'], '.', '');
    }

    function goOut() {
        global $cart;
        $cart->reset(true);
        tep_session_unregister('sendto');
        tep_session_unregister('billto');
        tep_session_unregister('shipping');
        tep_session_unregister('payment');
        tep_session_unregister('comments');
        tep_session_unregister('cart_vnpay_Standard_ID');

        tep_redirect(tep_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL'));
    }

}

?>
