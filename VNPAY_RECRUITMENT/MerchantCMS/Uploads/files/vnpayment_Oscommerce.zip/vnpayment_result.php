<?php

include('includes/application_top.php');


if (!function_exists('session_start')) {
    define('PHP_SESSION_ID', 'sesskey');
    define('PHP_SESSION_NAME', 'osCsid');
    define('PHP_SESSION_PATH', $cookie_path);
    define('PHP_SESSION_DOMAIN', $cookie_domain);
    define('PHP_SESSION_SAVE_PATH', SESSION_WRITE_DIRECTORY);

    include(DIR_WS_CLASSES . 'sessions.php');
}

$key = "";
$check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_VNPAY_SECRETKEY'");
if ($result = mysqli_fetch_array($check_query)) {
    $key = $result['configuration_value'];
}
$get = $_GET;
$vnp_TxnRef = $_GET['vnp_TxnRef'];
$vnp_SecureHash = $_GET['vnp_SecureHash'];
$vnp_TxnResponseCode = $_GET['vnp_ResponseCode'];
$hashSecret = $key;

// var_dump($get);
$data = array();
foreach ($get as $key => $value) {
    $data[$key] = $value;
}
unset($data["vnp_SecureHashType"]);
unset($data["vnp_SecureHash"]);
ksort($data);
$i = 0;
$data2 = "";
foreach ($data as $key => $value) {
    if ($i == 1) {
        $data2 .= '&' . $key . "=" . $value;
    } else {
        $data2 .= $key . "=" . $value;
        $i = 1;
    }
}
$secureHash = md5($hashSecret . $data2);
if ($secureHash == $vnp_SecureHash) {
    //var_dump(tep_db_query("select * from orders"));
    $s = "UPDATE `orders_status_history` SET `orders_status_id` = '2' WHERE `orders_status_history`.`orders_id` =" . $vnp_TxnRef;
    tep_db_query($s);
} else {
    $s = "UPDATE `orders_status_history` SET `orders_status_id` = '0' WHERE `orders_status_history`.`orders_id` =" . $vnp_TxnRef;
    tep_db_query($s);
}
$cart->reset(true);
$localtion = $_SESSION['location'];
$_SESSION['location']=null;
if ($vnp_TxnResponseCode == "00") {
    if ($localtion == 'vn' || $$localtion == 'vi') {
        ?>
<p style="text-align: center">Giao dịch được thực hiện thành công. Cảm ơn quý khách đã sử dụng dịch vụ</p>
        <hr/>
        <?php

    } else {
        ?>
         <p style="text-align: center">Payment success. Thank you!</p>
         <hr/>
        <?php

    }
} else {
    if ($localtion == 'vn' || $$localtion == 'vi') {
        ?>
          <p style="text-align: center">Giao dịch được thực hiện không thành công. Quý khách vui lòng thực hiện lại giao dịch</p>
          <hr/>
        <?php

    } else {
        ?>
           <p style="text-align: center">Payment failed. Please try a again!</p>
           <hr/>
        <?php
    }
} 
 //unregister session variables used during checkout
tep_session_unregister('sendto');
tep_session_unregister('billto');
tep_session_unregister('shipping');
tep_session_unregister('payment');
tep_session_unregister('comments');
//tep_redirect(tep_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL'));
require(DIR_WS_INCLUDES . 'application_bottom.php');
?>
<script type="text/javascript"><!--
setTimeout('location = \'<?php echo FILENAME_CHECKOUT_SUCCESS; ?>\';', 5000);
</script>
