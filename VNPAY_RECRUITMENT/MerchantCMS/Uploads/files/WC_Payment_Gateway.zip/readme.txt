== vnpayment.vn cho Woocommerce ==
Tags: woocommerce,vietnamese,vnpayment
Requires at least: 
Tested up to: 
Stable tag: 1.0.0

Tích hợp cổng thanh toán vnpayment.vn vào Woocommerce.

== Description ==
Tích hợp cổng thanh toán vnpayment.vn vào Woocommerce. Chỉnh sửa tên cổng thanh toán VnPay dễ dàng như các cổng thanh toán có sẵn của Woocommerce.


== Installation ==

1. Giải nén file WC_VNPay_plugin.rar
2. Kích hoạt plugin trong khu vực Plugins -> Installed Plugins -> Add New -> Upload Plugins -> chọn WC_Payment_Gateway.zip -> Nhấn Install Now
3. Vào Woocommerce -> Settings -> Checkout -> chọn VNPay và thiết lập các thông tin cần thiết cho cổng thanh toán
4. Copy thư mục \'assets\' vào wp-content/plugins/woocommerce
== Frequently Asked Questions ==
= Tôi có thể tùy chỉnh thông tin cổng thanh toán này không?
Có, dễ dàng chỉnh sửa tên và mô tả cổng thanh toán này như các cổng thanh toán có sẵn trong Woocommerce.


== Screenshots ==