<?php

/**
 * Plugin Name: VnPayment Gateway Woocommerce
 * Plugin URI: http://vnpayment.vn
 * Description: Đây là plugin tích hợp cổng thanh toán VnPayment
 * Version: 1.0
 * Author: vinhnt@vnpay.vn
 */
?>
<?php

add_action('plugins_loaded', 'woocommerce_VNPayment_init', 0);

function woocommerce_VNPayment_init() {
    if (!class_exists('WC_Payment_Gateway'))
        return;

    load_plugin_textdomain('wc-gateway-name', false, dirname(plugin_basename(__FILE__)) . '/languages');

    class WC_VNPay extends WC_Payment_Gateway {

        private $log_file, $fp;

        // set log file (path and name)
        public function lfile($path) {

            $this->log_file = $path;
        }

        // write message to the log file
        public function lwrite($message) {
            // if file pointer doesn't exist, then open log file
            if (!is_resource($this->fp)) {
                $this->lopen();
            }
            // define script name
            $script_name = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME);
            // define current time and suppress E_WARNING if using the system TZ settings
            // (don't forget to set the INI setting date.timezone)
            $time = @date('[d/M/Y:H:i:s]');
            // write current time, script name and message to the log file
            fwrite($this->fp, "$time ($script_name) $message" . PHP_EOL);
        }

        // close log file (it's always a good idea to close a file when you're done with it)
        public function lclose() {
            fclose($this->fp);
        }

        // open log file (private method)
        private function lopen() {
            // in case of Windows set default log file
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                $log_file_default = 'c:/php/logfile.txt';
            }
            // set default log file for Linux and other systems
            else {
                $log_file_default = '/tmp/logfile.txt';
            }
            // define log file from lfile method or use previously set default
            $lfile = $this->log_file ? $this->log_file : $log_file_default;
            // open log file for writing only and place file pointer at the end of the file
            // (if the file does not exist, try to create it)
            $this->fp = fopen($lfile, 'a') or exit("Can't open $lfile!");
        }

        public function __construct() {
            if (file_exists('/logs/vnpaylogs/woocommerce.txt')) {
                $this->lfile('/logs/vnpaylogs/woocommerce.txt');
            } else {
                mkdir('/logs/vnpaylogs/', 0777, true);
                touch('/logs/vnpaylogs/woocommerce.txt');
                $this->lfile('/logs/vnpaydemophp/woocommerce.txt');
            }
            $this->id = 'VNPay';
            $this->medthod_title = 'VnPayment (vnpayment.vn)';
            $this->has_fields = false;

            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->settings['title'];
            $this->description = $this->settings['description'];
            $this->merchant_id = $this->settings['merchant_id'];
            $this->secret_key = $this->settings['secret_key'];
            $this->access_code = $this->settings['access_code'];
            //
            $this->redirect_page_id = $this->settings['redirect_page_id'];
            $this->liveurl = 'http://sandbox.vnpayment.vn/paymentv2/vpcpay.html?';

            $this->redirect_url = str_replace('https:', 'http:', add_query_arg('wc-api', 'WC_VNPay', get_permalink($this->redirect_page_id)));
            $this->msg['message'] = "";
            $this->msg['class'] = "";

            add_action('woocommerce_api_wc_vnpay', array($this, 'check_vnpay_response'));
            if (version_compare(WOOCOMMERCE_VERSION, '2.0.8', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            } else {
                add_action('woocommerce_update_options_payment_gateways', array($this, 'process_admin_options'));
            }
            add_action('woocommerce_receipt_VNPay', array($this, 'receipt_page'));
        }

        function init_form_fields() {

            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Bật / Tắt', 'wcVNPay'),
                    'type' => 'checkbox',
                    'label' => __('Kích hoạt cổng thanh toán vnpayment.vn cho Woocommerce', 'wcVNPay'),
                    'default' => 'no'),
                'secret_key' => array(
                    'title' => __('Secret key', 'wcVNPay'),
                    'type' => 'text',
                    'label' => __('Mã bảo mật giao dịch', 'wcVNPay'),
                    'default' => 'no')
                ,
                'access_code' => array(
                    'title' => __('Access code', 'wcVNPay'),
                    'type' => 'text',
                    'label' => __('Mã truy cập', 'wcVNPay'),
                    'default' => 'no'
                ),
                'title' => array(
                    'title' => __('Tên:', 'wcVNPay'),
                    'type' => 'text',
                    'description' => __('Tên phương thức thanh toán ( khi khách hàng chọn phương thức thanh toán )', 'wcVNPay'),
                    'default' => __('VNPAY', 'wcVNPay')),
                'description' => array(
                    'title' => __('Mô tả:', 'wcVNPay'),
                    'type' => 'textarea',
                    'description' => __('Mô tả phương thức thanh toán.', 'wcVNPay'),
                    'default' => __('Thanh toán trực tuyến AN TOÀN, TIỆN LỢI, HƯỞNG ƯU ĐÃI Với VNPayment. Với vnpayment.vn Quý khách có thể thanh toán bằng thẻ Ngân Hàng.', 'wcVNPay')),
                'merchant_id' => array(
                    'title' => __('Tài khoản vnpayment.vn', 'wcVNPay'),
                    'type' => 'text',
                    'description' => __('Đây là tài khoản vnpayment.vn để nhận tiền của khách hàng.')),
                /**/
                'redirect_page_id' => array(
                    'title' => __('Trang trả về'),
                    'type' => 'select',
                    'options' => $this->get_pages('Hãy chọn...'),
                    'description' => "Hãy chọn trang/url để chuyển đến sau khi khách hàng đã thanh toán tại vnpayment.vn thành công."
                )
            );
        }

        public function admin_options() {
            echo '<h3>' . __('VnPay Payment Gateway', 'wcVNPay') . '</h3>';
            echo '<p>' . __('vnpayment.vn - Thanh toán trực tuyến AN TOÀN, TIỆN LỢI, HƯỞNG ƯU ĐÃI Với VNPay.');

            echo '<table class="form-table">';
            // Generate the HTML For the settings form.
            $this->generate_settings_html();
            echo '</table>';
        }

        /**
         *  There are no payment fields for BaoKimVN, but we want to show the description if set.
         * */
        function payment_fields() {
            if ($this->description)
                echo wpautop(wptexturize($this->description));
        }

        /**
         * Receipt Page
         * */
        function receipt_page($order) {
            $this->lwrite("receipt_page");

            echo '<p>' . __('Chúng tôi đã nhận được Đơn mua hàng của bạn. <br /><b>Tiếp theo, hãy bấm nút Thanh toán bên dưới để tiến hành thanh toán an toàn qua Vnpayment.vn ...', 'wcVNPay') . '</p>';

            echo $this->generate_VNPay_form($order);

            $this->lwrite("end_receipt_page");
        }

        /**
         * Generate VNPay button link
         * */
        public function generate_VNPay_form($order_id) {
            $base_url = get_site_url();

            global $woocommerce;
            $order = new WC_Order($order_id);

            $date = new DateTime(); //this returns the current date time
            $result = $date->format('Y-m-d-H-i-s');
            $today = date("Y-m-d H:i:s");
            $krr = explode('-', $result);
            $result1 = implode("", $krr);
            $total_amount = $order->order_total;
            $vnp_Url = $this->liveurl;
            $vnp_Returnurl = $this->redirect_url;
            $hashSecret = $this->secret_key;
            $vnp_Locale = "vn";
            $vnp_OrderInfo = 'Thanh toán đơn hàng' . ' Luc :' . $today;
            $vnp_OrderType = "topup";
            $vnp_Merchant = $this->merchant_id;
            $vnp_CurrCode = "VND";
            $vnp_AccessCode = $this->access_code;
            $vnp_Amount = $total_amount * 100;
            $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
            $Odarray = array(
                "vnp_AccessCode" => $vnp_AccessCode,
                "vnp_Amount" => $vnp_Amount,
                "vnp_Command" => "pay",
                "vnp_CreateDate" => $result1,
                "vnp_CurrCode" => $vnp_CurrCode,
                "vnp_IpAddr" => $vnp_IpAddr,
                "vnp_Locale" => $vnp_Locale,
                "vnp_Merchant" => $vnp_Merchant,
                "vnp_OrderInfo" => $vnp_OrderInfo,
                "vnp_OrderType" => $vnp_OrderType,
                "vnp_ReturnUrl" => $vnp_Returnurl,
                "vnp_TxnRef" => $order_id,
                "vnp_Version" => "1",
            );
            ksort($Odarray);
            $query = "";
            $i = 0;
            $data = "";
            foreach ($Odarray as $key => $value) {
                if ($i == 1) {
                    $data .= '&' . $key . "=" . $value;
                } else {
                    $data .= $key . "=" . $value;
                    $i = 1;
                }

                $query .= urlencode($key) . "=" . urlencode($value) . '&';
            }

            $vnp_Url .=$query;
            if (isset($hashSecret)) {
                $vnpSecureHash = md5($hashSecret . $data);
                $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
            }
            return '<form id="vpg_cpayment_form" action="">
                <center><input class="button" id="submit_vnpayment_form" value="Thanh toán">
                <script src="' . $base_url . '/wp-content/plugins/woocommerce/assets/js/javascript/jquery/jquery-2.1.1.min.js" type="text/javascript"></script>
                <link href="' . $base_url . '/wp-content/plugins/woocommerce/assets/js/javascript/colorbox/colorbox.css" rel="stylesheet" type="text/css">
                <script src="' . $base_url . '/wp-content/plugins/woocommerce/assets/js/javascript/colorbox/jquery.colorbox.js" type="text/javascript"></script>            
                <script type="text/javascript">
                    jQuery(function(){
                        jQuery("#submit_vnpayment_form").click(function () {
                            jQuery.colorbox({
                                iframe: true,
                                innerWidth: 350,
                                innerHeight: 500, overlayClose: false, scrolling: false,
                                href: "' . $vnp_Url . '",
                                onComplete: function () {
                                    var clrobj = $(this).colorbox;
                                    var w = 352;
                                    // Here "addEventListener" is for standards-compliant web browsers and "attachEvent" is for IE Browsers.
                                    var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
                                    var eventer = window[eventMethod];
                                    var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
                                    // Listen to message from child IFrame window
                                    eventer(messageEvent, function (e) {
                                        console.log("e.data = " + e.data);
                                        clrobj.resize({
                                            "height": e.data,
                                            "width": w
                                        });
                                        // Do whatever you want to do with the data got from IFrame in Parent form.
                                    }, false);
                                }
                            });
                        });
                    });
                </script>            
            </form>';
        }

        /**
         * Process the payment and return the result
         * */
        function process_payment($order_id) {
            $this->lwrite("process_payment");
            $order = new WC_Order($order_id);

            return array(
                'result' => 'success',
                'redirect' => add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay'))))
            );
        }

        /**
         * Check for valid payu server callback
         * */
        function check_vnpay_response() {
            $this->lwrite("check_vnpay_response");
            global $woocommerce;

            $this->lwrite($_REQUEST['vnp_TxnRef']);
            $this->lwrite($_REQUEST['vnp_ResponseCode']);
            $order_id_temp = $_REQUEST['vnp_TxnRef'];
            //$order_id = explode('_', $_REQUEST['txnid']);
            $order_id = (int) $order_id_temp;
            $this->lwrite($order_id);

            $vnp_SecureHash = $_REQUEST['vnp_SecureHash'];
            $vnp_TxnResponseCode = $_REQUEST['vnp_ResponseCode'];
            $hashSecret = $this->secret_key;
            $get = $_REQUEST;
            // var_dump($get);
            $data = array();
            foreach ($get as $key => $value) {
                $data[$key] = $value;
            }
            unset($data["vnp_SecureHashType"]);
            unset($data["vnp_SecureHash"]);
            //unset($data["route"]);
            ksort($data);
            $i = 0;
            $data2 = "";
            foreach ($data as $key => $value) {
                if ($key != 'wc-api') {
                    if ($i == 1) {
                        $data2 .= '&' . $key . "=" . $value;
                    } else {
                        $data2 .= $key . "=" . $value;
                        $i = 1;
                    }
                }
            }
            $this->lwrite($data2);
            $secureHash = md5($hashSecret . $data2);
            if ($secureHash == $vnp_SecureHash) {
                $this->lwrite("Verify success. Signal true");
                if ($order_id != '') {
                    try {
                        $order = new WC_Order($order_id);

                        $status = $_REQUEST['vnp_ResponseCode'];

                        $transauthorised = false;
                        $this->lwrite($order->status);

                        if ($order->status !== 'completed') {
                            $status = strtolower($status);
                            $this->lwrite($status);
                            if ($status == "00") {
                                $transauthorised = true;
                                //$this -> msg['message'] = "Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.";
                                $this->msg['message'] = "Bạn đã thực hiện giao dịch thành công. Chúng tôi sẽ giao hàng tới bạn trong thời gian ngắn nhất. Cám ơn bạn đã sử dụng dịch vụ của chúng tôi.";
                                $this->msg['class'] = 'success';
                                if ($order->status == 'processing') {
                                    
                                } else {
                                    $order->payment_complete();
                                    $order->add_order_note('VNPay payment successful<br/>Unnique Id from VNPayment: ' . $_REQUEST['vnp_TxnRef']);
                                    $order->add_order_note($this->msg['message']);
                                    $woocommerce->cart->empty_cart();
                                }
                            }
//                            else if ($status == "01") {
//                                //$this->msg['message'] = "Thank you for shopping with us. Right now your payment staus is pending, We will keep you posted regarding the status of your order through e-mail";
//                                $this->msg['message'] = "Cảm ơn bạn đã mua hàng của chúng tôi. Yêu cầu thanh toán của bạn đã được gửi, chúng tôi sẽ cập nhật trạng thái đơn hàng của bạn qua e-mail";
//                                $this->msg['class'] = 'woocommerce_message woocommerce_message_info';
//                                $order->add_order_note('VNPay payment status is pending<br/>Unnique Id from VNPayment: '.$_REQUEST['vnp_TxnRef']);
//                                $order->add_order_note($this->msg['message']);
//                                $order->update_status('on-hold');
//                                $woocommerce->cart->empty_cart();
//                            } 
                            else {
                                $this->msg['class'] = 'danger';
                                $this->msg['message'] = "Cảm ơn bạn đã mua hàng của chúng tôi. Nhưng giao dịch của bạn đã không thể thực hiện.";
                                $order->add_order_note('Giao dịch bị từ chối: ');
                                //Here you need to put in the routines for a failed
                                //transaction such as sending an email to customer
                                //setting database status etc etc
                            }

                            if ($transauthorised == false) {
                                $order->update_status('failed');
                                $order->add_order_note('Failed');
                                $order->add_order_note($this->msg['message']);
                            }
                            //add_action('the_content', array(&$this, 'showMessage'));
                        }
                    } catch (Exception $e) {
                        // $errorOccurred = true;
                        $msg = "Error";
                    }
                }
            } else {
                $this->msg['class'] = 'danger';
                $this->msg['message'] = "Sai check-sum";

                //Here you need to simply ignore this and dont need
                //to perform any operation in this condition
                $this->lwrite("Verify success. Signal false");
            }



            $this->lwrite($this->redirect_page_id);
            header('Content-Type: text/html; charset=utf-8');
            header( "refresh:5;url=" . $this->redirect_page_id); /* Redirect browser */
            //do_action('the_content', '');
            echo $this->showMessage("");
            exit();
        }

        function showMessage($content) {
            $base_url = get_site_url();
            $time = 5;
            $this->lwrite($this->msg['message']);
            return '<form class="form-horizontal">'
                    . '<link href="' . $base_url . '/wp-content/plugins/woocommerce/assets/js/javascript/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">'
                    . '<script src="' . $base_url . '/wp-content/plugins/woocommerce/assets/js/javascript/jquery/jquery-2.1.1.min.js" type="text/javascript"></script> '
                    . '<div class="col-md-12 center"><div class="alert alert-' . $this->msg['class'] . '" role="alert">' . $this->msg['message'] . '<br/>Hệ thống sẽ tự động chuyển trang sau (<label id="time_down">' . $time . '</label>s).</div>' . $content
                    . '</div>'
                    . '<script type="text/javascript">'
                    . 'function timerIncrement() {'
                    . 'var temp = jQuery("#time_down").text();'
                    . 'if(temp > 0){'
                    . 'temp -= 1;'
                    . '}'
                    . 'jQuery("#time_down").text(temp);'
                    . '}'
                    . 'jQuery(function(){'
                    . 'setInterval(timerIncrement, 1000);'
                    . '});'
                    . '</script>'
                    . '</form>';
        }

        // get all pages
        function get_pages($title = false, $indent = true) {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title)
                $page_list[] = $title;
            foreach ($wp_pages as $page) {
                $prefix = '';
                // show indented child pages?
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                // add to page list array array
                $page_list[$page->ID] = $prefix . $page->post_title;
            }
            return $page_list;
        }

    }

    function woocommerce_add_VNPay_gateway($methods) {
        $methods[] = 'WC_VNPay';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_VNPay_gateway');
}

?>