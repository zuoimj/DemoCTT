<?php
// Heading
$_['heading_title']      = 'Thanh toán qua VNPAYMENT';
$_['text_edit']          = 'Cập nhật VNPAYMENT';
$_['text_payment']       = 'Thanh toán';
$_['text_vnpayment']        = '<a href="http://vnpayment.vnpay.vn/" target="_blank"><img src="view/image/payment/vnpayment.png" alt="Vnpayment" title="Vnpayment" style="width: 95px;margin-top: 5px;" /></a>';
// Text 
$_['entry_order_status'] = 'Trạng thái đơn hàng sau thanh toán:';
$_['entry_status']       = 'Trạng thái kích hoạt:';
$_['entry_sort_order']   = 'Sort Order:';
$_['entry_access_code']  = 'Access Code';
$_['entry_url']       = 'URL VNPAY';
$_['entry_returnurl']       = 'URL Return';
$_['entry_types']='Loại hàng hóa';
$_['entry_currency']  = 'Tiền tệ';
$_['entry_merchant']='Merchant';
$_['entry_secretkey']='Secret key';
$_['entry_order_status'] = 'Trạng thái đơn hàng sau thanh toán:';
$_['text_success']       = 'Thanh toán trực tuyến an toàn với Vnpayment';
$_['error_access_code']     = 'Access Code không được trống!';
$_['error_url']     = 'URL VNPAY Không được trống!';
$_['error_returnurl']     = 'URL Return Không được trống!';
$_['error_types']     = 'Types Không được trống!';
$_['error_currency']     = 'Currency không được trống!';
$_['error_secretkey']  ='Secret key không được trống!';
$_['error_merchant']  ='Merchant key không được trống!';
?>
