<?php
// Heading
$_['heading_title']      = 'VNPAYMENT';
$_['text_payment']       = 'Payment';
$_['text_edit']          = 'Edit VNPAYMENT ';
$_['text_vnpayment']        = '<a href="http://vnpayment.vnpay.vn/" target="_blank"><img src="view/image/payment/vnpayment.png" alt="Vnpayment" title="Vnpayment" style="width: 95px;margin-top: 5px;" /></a>';
$_['entry_order_status'] = 'Order Status';
$_['entry_status']       = 'Status';
$_['entry_url']       = 'URL VNPAY';
$_['entry_returnurl']       = 'URL Return';
$_['entry_sort_order']   = 'Sort Order';
$_['entry_order_status'] = 'Order Status';
$_['entry_access_code']  = 'Access Code';
$_['entry_currency']  = 'Currency';
$_['entry_secretkey']='Secret key';
$_['entry_merchant']='Merchant';
$_['entry_types']='Types';
$_['text_success']       = 'Success: You have modified VNPAYMENT account details!';
$_['error_access_code']     = 'Access Code Required!';
$_['error_url']     = 'URL VNPAY Required!';
$_['error_returnurl']     = 'URL Return Required!';
$_['error_types']     = 'Types Required!';
$_['error_currency']     = 'Currency Required!';
$_['error_secretkey']  ='Secret key Required!';
$_['error_merchant']  ='Merchant key Required!';
?>
