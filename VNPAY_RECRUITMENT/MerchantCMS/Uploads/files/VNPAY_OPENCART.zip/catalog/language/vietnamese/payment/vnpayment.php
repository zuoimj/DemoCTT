<?php
// Text
$_['text_title'] = 'Thanh toán qua VNPAYMENT <br /><img src="http://vnpayment.vnpay.vn/Themes/Default/images/logo.gif" />';
$_['heading_title']     = 'Cảm ơn bạn đã thanh toán qua VNPAYMENT %s .... ';
$_['text_response']     = 'Phản hồi từ VNPAYMENT:';
$_['text_success']      = '... bạn đã thực hiện thanh toán thành công.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">Vui lòng đợi...</span></b> trong khi chúng tôi kết thúc xử lý đơn hàng của bạn.<br>Nếu tiến trình không tự động chuyển trong 10 giây, Chuyển ngay <a href="%s">tại đây</a>.';
$_['text_failure']      = '... Bạn thực hiện thanh toán không thành công!';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Vui lòng đợi...</span></b><br>Nếu tiến trình không tự động chuyển trong 10 giây, Chuyển ngay <a href="%s">tại đây</a>.';
?>
