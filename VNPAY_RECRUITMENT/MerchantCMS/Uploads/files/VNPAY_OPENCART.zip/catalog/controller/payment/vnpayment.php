<?php

/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment                           *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp trên trang                               *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */

class ControllerPaymentVnpayment extends Controller {

    private $log_file, $fp;

    // set log file (path and name)
    public function lfile($path) {

        $this->log_file = $path;
    }

    // write message to the log file
    public function lwrite($message) {
        // if file pointer doesn't exist, then open log file
        if (!is_resource($this->fp)) {
            $this->lopen();
        }
        // define script name
        $script_name = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME);
        // define current time and suppress E_WARNING if using the system TZ settings
        // (don't forget to set the INI setting date.timezone)
        $time = @date('[d/M/Y:H:i:s]');
        // write current time, script name and message to the log file
        fwrite($this->fp, "$time ($script_name) $message" . PHP_EOL);
    }

    // close log file (it's always a good idea to close a file when you're done with it)
    public function lclose() {
        fclose($this->fp);
    }

    // open log file (private method)
    private function lopen() {
        // in case of Windows set default log file
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $log_file_default = 'c:/php/logfile.txt';
        }
        // set default log file for Linux and other systems
        else {
            $log_file_default = '/tmp/logfile.txt';
        }
        // define log file from lfile method or use previously set default
        $lfile = $this->log_file ? $this->log_file : $log_file_default;
        // open log file for writing only and place file pointer at the end of the file
        // (if the file does not exist, try to create it)
        $this->fp = fopen($lfile, 'a') or exit("Can't open $lfile!");
    }

    public function index() {
        $this->load->language('payment/vnpayment');
        $this->load->model('checkout/order');
        $data['button_confirm'] = $this->language->get('button_confirm');
        $data['button_back'] = $this->language->get('button_back');
        //echo '<script>window.location = "' . $data['continue'] . '"</script>';
        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/vnpayment.tpl')) {
            return $this->load->view($this->config->get('config_template') . '/template/payment/vnpayment.tpl', $data);
        } else {
            return $this->load->view('/payment/vnpayment.tpl', $data);
        }
    }

    public function confirm() {
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $order_id = $this->session->data['order_id'];
        $total_amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
        $order_description = $order_info['comment'];
        if (file_exists('/logs/vnpaylogs/vnplog.txt')) {
            $this->lfile('/logs/vnpaylogs/vnplog.txt');
        } else {
            mkdir('/logs/vnpaylogs/', 0777, true);
            touch('/logs/vnpaylogs/vnplog.txt');
            $this->lfile('/logs/vnpaydemophp/vnplog.txt');
        }
        $date = new DateTime(); //this returns the current date time
        $result = $date->format('Y-m-d-H-i-s');
        $today = date("Y-m-d H:i:s");
        $krr = explode('-', $result);
        $result1 = implode("", $krr);
        $this->session->data['time'] = $result1;
        $vnp_Url = $this->config->get('vnpayment_url');
        $vnp_Returnurl = $this->config->get('config_ssl')."index.php?route=payment/vnpayment/Return_Success";
        $hashSecret = $this->config->get('vnpayment_secretkey');
        $vnp_Locale = $this->language->get('code');
        $vnp_OrderInfo = $order_description . ' Luc :' . $today;
        $vnp_OrderType = $this->config->get('vnpayment_types');
        $vnp_Merchant = $this->config->get('vnpayment_merchant');
        $vnp_CurrCode = $this->config->get('vnpayment_currency');
        $vnp_AccessCode = $this->config->get('vnpayment_access_code');
        $vnp_Amount = $total_amount * 100;
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
        $Odarray = array(
            "vnp_AccessCode" => $vnp_AccessCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => $result1,
            "vnp_CurrCode" => $vnp_CurrCode,
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_Merchant" => $vnp_Merchant,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $order_id,
            "vnp_Version" => "1",
        );
        ksort($Odarray);
        $query = "";
        $i = 0;
        $data = "";
        foreach ($Odarray as $key => $value) {
            if ($i == 1) {
                $data .= '&' . $key . "=" . $value;
            } else {
                $data .= $key . "=" . $value;
                $i = 1;
            }

            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }
		$vnp_Url .='?';
        $vnp_Url .=$query;
        if (isset($hashSecret)) {
            $vnpSecureHash = md5($hashSecret . $data);
            $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
            $this->lwrite('========================================================');
            $this->lwrite('HashData=' . $hashSecret . $data);
            $this->lwrite('SecureHash=' . $vnpSecureHash);
            $this->lwrite('RedirectUrl=' . $vnp_Url);
            $this->lwrite('========================================================');
        }
        $OrdersArray = array('code' => '00'
            , 'message' => 'success'
            , 'data' => $vnp_Url);
        echo json_encode($OrdersArray);
        $this->lclose();
        die;
    }

    public function Return_Success() {
        $order_id = 0;
        $status = '';
        $message = '';
        if (isset($this->request->get['vnp_TxnRef'])) {
            $order_id = $this->request->get['vnp_TxnRef'];
        } else {
            $message = '';
            $order_id = 0;
        }
        if (file_exists('/logs/vnpaylogs/vnplog.txt')) {
            $this->lfile('/logs/vnpaylogs/vnplog.txt');
        } else {
            mkdir('/logs/vnpaylogs/', 0777, true);
            touch('/logs/vnpaylogs/vnplog.txt');
            $this->lfile('/logs/vnpaydemophp/vnplog.txt');
        }
        $vnp_SecureHash = $_GET['vnp_SecureHash'];
        $vnp_TxnResponseCode = $this->request->get['vnp_ResponseCode'];
        $hashSecret = $this->config->get('vnpayment_secretkey');
        $get = $_GET;
        // var_dump($get);
        $data = array();
        foreach ($get as $key => $value) {
            $data[$key] = $value;
        }
        unset($data["vnp_SecureHashType"]);
        unset($data["vnp_SecureHash"]);
        unset($data["route"]);
        ksort($data);
        $i = 0;
        $data2 = "";
        foreach ($data as $key => $value) {
            if ($i == 1) {
                $data2 .= '&' . $key . "=" . $value;
            } else {
                $data2 .= $key . "=" . $value;
                $i = 1;
            }
        }
        $secureHash = md5($hashSecret . $data2);
        if ($vnp_TxnResponseCode == '00') {
            $status = $vnp_TxnResponseCode;
        } else {
            $message = "Dữ liệu không hợp lệ !";
            $status = '';
        }
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($order_id);
        if ($order_info && $secureHash == $vnp_SecureHash) {
            $this->language->load('payment/vnpayment');
            $data['title'] = sprintf($this->language->get('heading_title'), $this->config->get('config_name'));

            if (!isset($this->request->server['HTTPS']) || ($this->request->server['HTTPS'] != 'on')) {
                $data['base'] = HTTP_SERVER;
            } else {
                $data['base'] = HTTPS_SERVER;
            }
            $data['language'] = $this->language->get('code');
            $data['direction'] = $this->language->get('direction');
            $data['heading_title'] = sprintf($this->language->get('heading_title'), $this->config->get('config_name'));
            $data['text_response'] = $this->language->get('text_response');
            $data['text_success'] = $this->language->get('text_success');
            $data['text_success_wait'] = sprintf($this->language->get('text_success_wait'), $this->url->link('checkout/success'));
            $data['text_failure'] = $this->language->get('text_failure');
            $data['text_failure_wait'] = sprintf($this->language->get('text_failure_wait'), $this->url->link('checkout/cart'));

            if ($status) {
                $this->load->model('checkout/order');
                $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('vnpayment_order_status_id'), $message, false);
//                $this->model_checkout_order->confirm($order_id, $this->config->get('config_order_status_id'));
//                $this->model_checkout_order->update($order_id, $this->config->get('vnpayment_order_status_id'), $message, false);
                $data['continue'] = $this->url->link('checkout/success');

                if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/vnpayment_success.tpl')) {
                    $this->template = $this->config->get('config_template') . '/template/payment/vnpayment_success.tpl';
                } else {
                    $this->template = 'default/template/payment/vnpayment_success.tpl';
                }

                $this->children = array(
                    'common/column_left',
                    'common/column_right',
                    'common/content_top',
                    'common/content_bottom',
                    'common/footer',
                    'common/header'
                );

                $this->response->setOutput($this->load->view($this->template, $data));
            } else {
                $data['continue'] = $this->url->link('checkout/cart');

                if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/vnpayment_fail.tpl')) {
                    $this->template = $this->config->get('config_template') . '/template/payment/vnpayment_fail.tpl';
                } else {
                    $this->template = 'default/template/payment/vnpayment_fail.tpl';
                }

                $this->children = array(
                    'common/column_left',
                    'common/column_right',
                    'common/content_top',
                    'common/content_bottom',
                    'common/footer',
                    'common/header'
                );
                $this->response->setOutput($this->load->view($this->template, $data));
            }
        }
    }

}

?>