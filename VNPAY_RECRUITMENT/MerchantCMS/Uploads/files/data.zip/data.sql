INSERT INTO `xf_post` (`post_id`, `thread_id`, `user_id`, `username`, `post_date`, `message`, `last_edit_date`, `message_state`) VALUES(
16,16, 1, 'admin', 1450809208, FROM_BASE64('MTIzIEFCQyAgY+G7mW5nIGjDsmE='), 450809208, 'visible');

INSERT INTO `xf_thread` (`thread_id`, `node_id`, `title`, `user_id`, `username`, `post_date`, `discussion_open`, `discussion_type`, `last_post_date`, `discussion_state`) VALUES
(16, 7, 'Thread13', 1, 'admin', 1450809208, 1, '', 1450609208, 'visible');