
jQuery(document).ready(function () {
    jQuery(".btn-checkout").submit(function () {
        alert("ok");
        jQuery.ajax({
            type: "POST",
            url: "",
            dataType: "JSON",
            success: function (getData) {
                if (getData.code === "00") {
                    $.colorbox({
                        iframe: true,
                        innerWidth: 350,
                        innerHeight: 500, overlayClose: false, scrolling: false,
                        href: getData.data,
                        onComplete: function () {
                            var clrobj = $(this).colorbox;
                            var w = 352;
                            // Here "addEventListener" is for standards-compliant web browsers and "attachEvent" is for IE Browsers.
                            var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
                            var eventer = window[eventMethod];
                            var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
                            // Listen to message from child IFrame window
                            eventer(messageEvent, function (e) {
                                console.log("e.data = " + e.data);
                                clrobj.resize({
                                    "height": e.data,
                                    "width": w
                                });
                                // Do whatever you want to do with the data got from IFrame in Parent form.
                            }, false);

                        }
                    });
                    return false;
                } else {
                    alert(x.Message);
                }

            }
        });

        return false;
    });
});
 