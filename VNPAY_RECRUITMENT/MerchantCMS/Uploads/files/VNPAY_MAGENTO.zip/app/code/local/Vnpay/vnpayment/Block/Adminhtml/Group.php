<?php
/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment cho magento               *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp                                          *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */
class Vnpay_vnpayment_Block_Adminhtml_Group extends Mage_Adminhtml_Block_System_Config_Form_Fieldset{
	/**
	 * Return header comment part of html for fieldset
	 *
	 * @param Varien_Data_Form_Element_Abstract $element
	 * @return string
	 */
	protected function _getHeaderCommentHtml($element)
	{

		$html = '<div class="vnpay-config-heading" ><div class="heading"><strong>Cổng Thanh Toán VNPAYMENT';
		$html .= '</strong>';
		  $html .= '<a class="link-more" href="http://vnpayment.vn/" target="_blank">'
			 . $this->__('  Learn More') . '</a>';

		$groupConfig = $this->getGroup($element)->asArray();

		if (empty($groupConfig['help_url']) || !$element->getComment()) {
			return parent::_getHeaderCommentHtml($element);
		}

		$html .= '<div class="comment">' . $element->getComment()
			. '</div></div>';

		$html .= '<div class="bk-allinone"></div>';
		$html .= '</div>';



		return $html;
	}

	/**
	 * Return collapse state
	 *
	 * @param Varien_Data_Form_Element_Abstract $element
	 * @return bool
	 */
	protected function _getCollapseState($element)
	{
		$extra = Mage::getSingleton('admin/session')->getUser()->getExtra();
		if (isset($extra['configState'][$element->getId()])) {
			return $extra['configState'][$element->getId()];
		}

		if ($element->getExpanded() !== null) {
			return 1;
		}

		return false;
	}
}