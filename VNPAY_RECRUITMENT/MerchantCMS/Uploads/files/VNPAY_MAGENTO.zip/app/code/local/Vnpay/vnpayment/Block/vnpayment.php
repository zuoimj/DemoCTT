﻿<?php
/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment cho magento               *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp                                          *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */
class Vnpay_vnpayment_Block_vnpayment extends Mage_Checkout_Block_Onepage_Success {

    private $vnpayment_merchant;
    private $vnpayment_secretkey;
    private $vnpayment_access_code;
    private $vnpayment_url;
    private $vnpayment_types;

    function __construct($vnpayment_merchant, $vnpayment_secretkey, $vnpayment_access_code, $vnpayment_url, $vnpayment_types) {
        $this->vnpayment_merchant = $vnpayment_merchant;
        $this->vnpayment_secretkey = $vnpayment_secretkey;
        $this->vnpayment_access_code = $vnpayment_access_code;
        $this->vnpayment_url = $vnpayment_url;
        $this->vnpayment_types = $vnpayment_types;
    }
    public function vnpayment() {
        $base_url=Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
        $callconfig = new Vnpay_vnpayment_Model_vnpayment();
        $config=$callconfig->call_API();
        $vnpayment_merchant = $config['vnp_Merchant'];
        $vnpayment_secretkey = $config['vnpayment_secretkey'];
        $vnpayment_access_code = $config['vnp_AccessCode'];
        $vnpayment_url = $config['vnpayment_url'];
        $vnpayment_types = $config['vnp_OrderType'];
        $order_code = $this->__($this->escapeHtml($this->getOrderId()));
        $order = Mage::getModel('sales/order')->loadByIncrementId($this->getOrderId());
        $price = $order->getTotalDue();
        $this->__construct($vnpayment_merchant, $vnpayment_secretkey, $vnpayment_access_code, $vnpayment_url, $vnpayment_types);
        $locale = Mage::app()->getLocale()->getLocaleCode();
        $date = new DateTime(); //this returns the current date time
        $result = $date->format('Y-m-d-H-i-s');
        $today = date("Y-m-d H:i:s");
        $krr = explode('-', $result);
        $result1 = implode("", $krr);
        $vnp_Url = $vnpayment_url;
        $vnp_Returnurl = $base_url.'complete.php';
        $hashSecret = $vnpayment_secretkey;
        $vnp_Locale = $locale;
        $vnp_OrderInfo = 'Thanh toan don hang tu Website ' . Mage::getUrl('') . ' voi ma don hang ' . $order_code;
        $vnp_OrderType = $vnpayment_types;
        $vnp_Merchant = $vnpayment_merchant;
        $vnp_CurrCode = strval($order->getBaseCurrencyCode());
        $vnp_Amount = $price * 100;
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
        $Odarray = array(
            "vnp_AccessCode" => $vnpayment_access_code,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => $result1,
            "vnp_CurrCode" => $vnp_CurrCode,
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_Merchant" => $vnp_Merchant,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $order_code,
            "vnp_Version" => "1",
        );
        ksort($Odarray);
        $query = "";
        $i = 0;
        $data = "";
        foreach ($Odarray as $key => $value) {
            if ($i == 1) {
                $data .= '&' . $key . "=" . $value;
            } else {
                $data .= $key . "=" . $value;
                $i = 1;
            }

            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }
	$vnp_Url .='?';
        $vnp_Url .=$query;
        if (isset($hashSecret)) {
            $vnpSecureHash = md5($hashSecret . $data);
            $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
        }
        $OrdersArray = array('code' => '00'
            , 'message' => 'success'
            , 'data' => $vnp_Url);
        return json_encode($OrdersArray);
        //  die;
    }

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

    public function getvnpayment() {
        if (!$this->hasData('vnpayment')) {
            $this->setData('vnpayment', Mage::registry('vnpayment'));
        }
        return $this->getData('vnpayment');
    }

}
