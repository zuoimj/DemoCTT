<?php
/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment cho magento               *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp                                          *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */
class Vnpay_vnpayment_Block_Info_vnpayment extends Mage_Payment_Block_Info {

    protected $_vnpayment_merchant;
    protected $_vnpayment_secretkey;
    protected $_vnpayment_access_code;
    protected $_vnpayment_url;
    protected $_vnpayment_types;

    protected function _construct() {
        parent::_construct();
        $this->setTemplate('payment/info/vnpayment.phtml');
    }

    /**
     * Enter description here...
     *
     * @return string
     */
    public function get_vnpayment_merchant() {
        if (is_null($this->_vnpayment_merchant)) {
            $this->_convertAdditionalData();
        }
        return $this->_vnpayment_merchant;
    }

    public function get_vnpayment_secretkey() {
        if (is_null($this->_vnpayment_secretkey)) {
            $this->_convertAdditionalData();
        }
        return $this->_vnpayment_secretkey;
    }

    public function get_vnpayment_access_code() {
        if (is_null($this->_vnpayment_access_code)) {
            $this->_convertAdditionalData();
        }
        return $this->_vnpayment_access_code;
    }

    public function get_vnpayment_url() {
        if (is_null($this->_vnpayment_url)) {
            $this->_convertAdditionalData();
        }
        return $this->_vnpayment_url;
    }

    public function get_vnpayment_types() {
        if (is_null($this->_vnpayment_types)) {
            $this->_convertAdditionalData();
        }
        return $this->_vnpayment_types;
    }

    

    /**
     * Enter description here...
     *
     * @return Mage_Payment_Block_Info_Checkmo
     */
    protected function _convertAdditionalData() {
        $details = @unserialize($this->getInfo()->getAdditionalData());
        if (is_array($details)) {
            $this->_vnpayment_merchant = isset($details['vnpayment_merchant']) ? (string) $details['vnpayment_merchant'] : '';
            $this->_vnpayment_secretkey = isset($details['vnpayment_secretkey']) ? (string) $details['vnpayment_secretkey'] : '';
            $this->_vnpayment_access_code = isset($details['vnpayment_access_code']) ? (string) $details['vnpayment_access_code'] : '';
            $this->_vnpayment_url = isset($details['vnpayment_url']) ? (string) $details['vnpayment_url'] : '';
            $this->_vnpayment_types = isset($details['vnpayment_types']) ? (string) $details['vnpayment_types'] : '';
        } else {
            $this->_vnpayment_merchant = '';
            $this->_vnpayment_secretkey = '';
            $this->_vnpayment_access_code = '';
            $this->_vnpayment_url = '';
            $this->_vnpayment_types = '';
        }
        return $this;
    }

    public function toPdf() {
        $this->setTemplate('payment/info/pdf/vnpayment.phtml');
        return $this->toHtml();
    }

}
