<?php
/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment cho magento               *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp                                          *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */
class Vnpay_vnpayment_Model_vnpayment extends Mage_Payment_Model_Method_Abstract {

    protected $_code = 'vnpayment';
    protected $_formBlockType = 'vnpayment/form_vnpayment';
    protected $_infoBlockType = 'vnpayment/info_vnpayment';

    public function assignData($data) {
        $details = array();
        if ($this->get_vnpayment_merchant()) {
            $details['vnpayment_merchant'] = $this->get_vnpayment_merchant();
        }
        if ($this->get_vnpayment_secretkey()) {
            $details['vnpayment_secretkey'] = $this->get_vnpayment_secretkey();
        }
        if ($this->get_vnpayment_access_code()) {
            $details['vnpayment_access_code'] = $this->get_vnpayment_access_code();
        }
        if ($this->get_vnpayment_url()) {
            $details['vnpayment_url'] = $this->get_vnpayment_url();
        }
        if ($this->get_vnpayment_types()) {
            $details['vnpayment_types'] = $this->get_vnpayment_types();
        }
        return $this;
    }

    public function get_vnpayment_merchant() {
        return $this->getConfigData('vnpayment_merchant');
    }

    public function get_vnpayment_secretkey() {
        return $this->getConfigData('vnpayment_secretkey');
    }

    public function get_vnpayment_access_code() {
        return $this->getConfigData('vnpayment_access_code');
    }

    public function get_vnpayment_url() {
        return $this->getConfigData('vnpayment_url');
    }

    public function get_vnpayment_types() {
        return $this->getConfigData('vnpayment_types');
    }

    function call_API() {
        $vnpayment_merchant = $this->getConfigData('vnpayment_merchant');
        $vnpayment_secretkey = $this->getConfigData('vnpayment_secretkey');
        $vnpayment_access_code = $this->getConfigData('vnpayment_access_code');
        $vnpayment_url = $this->getConfigData('vnpayment_url');
        $vnpayment_types = $this->getConfigData('vnpayment_types');
        $params["vnp_AccessCode"] = $vnpayment_access_code;
        $params ["vnp_Merchant"] = $vnpayment_merchant;
        $params["vnp_OrderType"] = $vnpayment_types;
        $params ["vnpayment_url"] = $vnpayment_url;
        $params ["vnpayment_secretkey"] = $vnpayment_secretkey;
        return $params;
    }

}
