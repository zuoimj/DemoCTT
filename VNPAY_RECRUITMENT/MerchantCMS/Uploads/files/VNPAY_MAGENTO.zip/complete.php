<?php
/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment cho Magento               *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp                                          *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */
?>

<?php
if (version_compare(phpversion(), '5.2.0', '<') === true) {
    echo '<div style="font:12px/1.35em arial, helvetica, sans-serif;"><div style="margin:0 0 25px 0; border-bottom:1px solid #ccc;"><h3 style="margin:0; font-size:1.7em; font-weight:normal; text-transform:none; text-align:left; color:#2f2f2f;">Whoops, it looks like you have an invalid PHP version.</h3></div><p>Magento supports PHP 5.2.0 or newer. <a href="http://www.magentocommerce.com/install" target="">Find out</a> how to install</a> Magento using PHP-CGI as a work-around.</p></div>';
    exit;
}
include_once 'app/Mage.php';
Mage::app();
$write = Mage::getSingleton('core/resource')->getConnection('wp_write');
if (isset($_GET['vnp_SecureHash']) && !empty($_GET['vnp_SecureHash'])) {
    $base_url = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
    $configmagento = new Vnpay_vnpayment_Model_vnpayment();
    $configKey = $configmagento->call_API();
    $order_id = 0;
    $status = '';
    $message = '';
    if (isset($_GET['vnp_TxnRef'])) {
        $order_id = $_GET['vnp_TxnRef'];
    } else {
        $message = '';
        $order_id = 0;
    }
    $vnp_SecureHash = $_GET['vnp_SecureHash'];
    $vnp_TxnResponseCode = $_GET['vnp_ResponseCode'];
    $hashSecret = $configKey['vnpayment_secretkey'];
    $get = $_GET;
    $data = array();
    foreach ($get as $key => $value) {
        $data[$key] = $value;
    }
    unset($data["vnp_SecureHashType"]);
    unset($data["vnp_SecureHash"]);
    ksort($data);
    $i = 0;
    $data2 = "";
    foreach ($data as $key => $value) {
        if ($i == 1) {
            $data2 .= '&' . $key . "=" . $value;
        } else {
            $data2 .= $key . "=" . $value;
            $i = 1;
        }
    }
    $secureHash = md5($hashSecret . $data2);
    if ($vnp_TxnResponseCode == '00') {
        $status = $vnp_TxnResponseCode;
    } else {
        $message = "Dữ liệu không hợp lệ !";
        $status = '';
    }
    if ($vnp_TxnResponseCode == '00' && $vnp_SecureHash == $secureHash) {
        $price = $_GET['vnp_Amount'];
        $tb1 = Mage::getSingleton('core/resource')->getTableName('sales_flat_order_grid');
        $increment_id = intval($order_id);
        $orderInfo = $write->fetchAll("SELECT * FROM " . $tb1 . " WHERE increment_id=" . $increment_id . " LIMIT 0 , 1");

        $entity_id = $orderInfo[0]['entity_id'];
        $tb = Mage::getSingleton('core/resource')->getTableName('sales_flat_order_payment');
        $query = "SELECT additional_data FROM " . $tb . " WHERE entity_id=" . $entity_id;
        $data = $write->fetchAll($query);

        $data_ = unserialize($data['0']['additional_data']);
        $merchant_site_code = $data_["merchantID"];
        $secure_pass = $data_["secure_code"];

        $table2 = Mage::getSingleton('core/resource')->getTableName('sales_flat_order_grid');
        $table = Mage::getSingleton('core/resource')->getTableName('sales_flat_order');

        $tb = Mage::getSingleton('core/resource')->getTableName('sales_flat_order_grid');
        $query = "SELECT * FROM " . $tb . " WHERE entity_id=" . $entity_id;
        $data = $write->fetchAll($query);

        $ordercode = $data[0]['increment_id'];
        $namebill = $data[0]['billing_name'];
        $pri = $data[0]['base_grand_total'];
        ?>
        <style>
            *{ font-family:Arial, Helvetica, sans-serif;}
            a{ text-decoration:none; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#0000CC; }
            a:hover{ font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#FF6600; }
        </style>
        <title>C&#7853;p nh&#7853;t thanh to&aacute;n</title>
        <link rel="shortcut icon" href="http://vnpayment.vnpay.vn/Themes/Default/images/logo.gif" />
        <body style="text-align:center;vertical-align:top"><center>
            <table width="300" style="margin:100px;" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="200"><a href="http://vnpayment.vnpay.vn/" title=""><img style="margin-bottom:20px;" src="http://vnpayment.vnpay.vn/Themes/Default/images/logo.gif" alt="Thanh toán qua VNPAY" border="0"/></a></td>
                    <td></td>
                </tr>
                <tr>
                    <td align="right" height="40" colspan="2" style="border-bottom:#666666 dotted 1px; font-size:11px; color:#666666;">Tr&#7841;ng th&aacute;i thanh to&aacute;n</td>
                </tr>
                <tr>
                    <td width="200" align="right" height="30"><strong style="font-size:12px;color:#666666;">Tr&#7841;ng th&aacute;i thanh to&aacute;n:</strong></td>
                    <td><i style="color:#006600; font-size:11px;">&nbsp; &radic; Th&agrave;nh c&ocirc;ng</i></td>
                </tr>
                <?php
                $u = $write->query("UPDATE {$table} SET status='pay_nl' WHERE entity_id='{$entity_id}'");
                $u1 = $write->query("UPDATE {$table2} SET status='pay_nl' WHERE entity_id='{$entity_id}'");

                if ($u) {
                    ?>
                    <tr>
                        <td align="right" height="20"><strong style="font-size:12px;color:#666666;">Tr&#7841;ng th&aacute;i c&#7853;p nh&#7853;t h&oacute;a &#273;&#417;n:</strong></td>
                        <td><i style="color:#006600; font-size:11px;">&nbsp; &radic;Th&agrave;nh c&ocirc;ng</i></td>
                    </tr>
                    <?php
                } else {
                    ?>
                    <tr>
                        <td align="right" height="20"><strong style="font-size:12px;color:#666666;">Tr&#7841;ng th&aacute;i c&#7853;p nh&#7853;t h&oacute;a &#273;&#417;n:</strong></td>
                        <td><i style="color:#006600; font-size:11px; color:#FF6600;">&nbsp; &radic;M&aacute;y ch&#7911; t&#7915; ch&#7889;i k&#7871;t n&#7889;i</i></td>
                    </tr>
                    <?php
                }
                ?>
                <tr>
                    <td align="right" height="40" colspan="2" style="border-bottom:#666666 dotted 1px; font-size:11px; color:#666666;">Th&ocirc;ng tin thanh to&aacute;n</td>
                </tr>
                <tr>
                    <td width="200" align="right" height="30"><strong style="font-size:12px;color:#666666;">M&atilde; h&oacute;a &#273;&#417;n:</strong></td>
                    <td><span style="color:#006600; font-size:11px;">&nbsp; <?php echo $ordercode; ?></span></td>
                </tr>

                <tr>
                    <td align="right" height="20"><strong style="font-size:12px;color:#666666;">S&#7889; ti&#7873;n:</strong></td>
                    <td><span style="color:#006600; font-size:11px;">&nbsp; <?php echo ceil($pri); ?>
                            VN&#272;</span></td>
                </tr>

                <tr>
                    <td align="right" height="20"><strong style="font-size:12px;color:#666666;">Lo&#7841;i thanh to&aacute;n:</strong></td>
                    <td><span style="color:#006600; font-size:11px;">&nbsp; <?php echo ($payment_type == "2") ? "<span style='color:#FF6600'>T&#7841;m gi&#7919;</span>" : "Thanh to&aacute;n ngay" ?></span></td>
                </tr>
                <tr>
                    <td align="right" height="20"><strong style="font-size:12px;color:#666666;">C&#7843;nh b&aacute;o:</strong></td>
                    <td><span style="color:#006600; font-size:11px;">&nbsp; <?php echo ($error_text != "") ? "<span style='color:#FF6600'>" . $error_text . "</span>" : "Kh&ocirc;ng" ?></span></td>
                </tr>

                <tr>
                    <td align="right" height="30"><a href="<?php echo $base_url; ?>" title="Trang chủ">&laquo; TRANG CHỦ</a>&nbsp; </td>
                    <td>&nbsp; <a href="http://vnpayment.vnpay.vn/" title="Cong thanh toan truc tuyen VNPAYMENT">VNPAY &raquo;</a> </td>
                </tr>
            </table>

        </center>
        <?php
    }
}
?>
</body>
</html>
