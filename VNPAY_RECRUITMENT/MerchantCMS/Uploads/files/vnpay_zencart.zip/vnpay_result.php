<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include('includes/application_top.php');

$key = "";
$check_query = $db->Execute("select configuration_value from configuration where configuration_key = 'MODULE_PAYMENT_VNPAY_SECRETKEY'");
$key = $check_query->fields['configuration_value'];
//echo($_SESSION['languages_code']);
//echo($key);
$get = $_GET;
$vnp_TxnRef = $_GET['vnp_TxnRef'];
$vnp_SecureHash = $_GET['vnp_SecureHash'];
$vnp_TxnResponseCode = $_GET['vnp_ResponseCode'];
$hashSecret = $key;
$data = array();
foreach ($get as $key => $value) {
    $data[$key] = $value;
}
unset($data["vnp_SecureHashType"]);
unset($data["vnp_SecureHash"]);
unset($data["route"]);
ksort($data);
$i = 0;
$data2 = "";
foreach ($data as $key => $value) {
    if ($i == 1) {
        $data2 .= '&' . $key . "=" . $value;
    } else {
        $data2 .= $key . "=" . $value;
        $i = 1;
    }
}
$secureHash = md5($hashSecret . $data2);
if ($secureHash == $vnp_SecureHash) {
    $s = "UPDATE `orders_status_history` SET `orders_status_id` = '2' WHERE `orders_status_history`.`orders_id` =" . $vnp_TxnRef;
    $db->Execute($s);
} else {
    $s = "UPDATE `orders_status_history` SET `orders_status_id` = '1' WHERE `orders_status_history`.`orders_id` =" . $vnp_TxnRef;
    $db->Execute($s);
}
$_SESSION['cart']->reset(true);

if ($vnp_TxnResponseCode == "00") {
    if ($_SESSION['languages_code'] == 'vn' || $_SESSION['languages_code'] == 'vi') {
        ?>
        <p style="text-align: center">Giao dịch được thực hiện thành công. Cảm ơn quý khách đã sử dụng dịch vụ</p>
        <hr/>
        <?php
    } else {
        ?>
        <p style="text-align: center">Payment success. Thank you!</p>
        <hr/>
        <?php
    }
} else {
    if ($_SESSION['languages_code'] == 'vn' || $_SESSION['languages_code'] == 'vi') {
        ?>
        <p style="text-align: center">Giao dịch được thực hiện không thành công. Quý khách vui lòng thực hiện lại giao dịch</p>
        <hr/>
        <?php
    } else {
        ?>
        <p style="text-align: center">Payment failed. Please try a again!</p>
        <hr/>
        <?php
    }
}
//unregister session variables used during checkout
unset($_SESSION['sendto']);
unset($_SESSION['billto']);
unset($_SESSION['shipping']);
unset($_SESSION['payment']);
unset($_SESSION['comments']);

//tep_redirect(tep_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL'));
require(DIR_WS_INCLUDES . 'application_bottom.php');
?>
<script type="text/javascript"><!--
setTimeout('location = \'<?php zen_redirect(zen_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL')); ?>\';', 5000);
</script>