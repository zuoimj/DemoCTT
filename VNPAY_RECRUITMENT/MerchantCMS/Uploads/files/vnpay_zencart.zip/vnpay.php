<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of vnpay
 *
 * @author khoakd@vnpay.vn
 */
class vnpay {

    //put your code here
    var $code, $title, $description, $enabled;

    function vnpay() {
        global $order;
        global $order;

        $this->code = 'vnpay';
        $this->title = 'VNPAYMENT';
        $this->description = 'VNPAYMENT';
        $this->merchantid = defined('MODULE_PAYMENT_VNPAY_MERCHANT') ? MODULE_PAYMENT_VNPAY_MERCHANT : '';
        $this->enabled = defined('MODULE_PAYMENT_VNPAY_MERCHANT') && (MODULE_PAYMENT_VNPAY_MERCHANT != null) ? true : false;
        $this->accesscode = defined('MODULE_PAYMENT_VNPAY_ACCESSCODE') ? MODULE_PAYMENT_VNPAY_ACCESSCODE : "";
        $this->secretkey = defined('MODULE_PAYMENT_VNPAY_SECRETKEY') ? MODULE_PAYMENT_VNPAY_SECRETKEY : "";
        $this->url_vnpay = defined('MODULE_PAYMENT_VNPAY_URL_VNPAY') ? MODULE_PAYMENT_VNPAY_URL_VNPAY : "";
        $this->url_return = defined('MODULE_PAYMENT_VNPAY_URL_RETURN') ? MODULE_PAYMENT_VNPAY_URL_RETURN : "";
        if (is_object($order))
            $this->update_status();
    }

    private $log_file, $fp, $amount;

    // set log file (path and name)
    public function lfile($path) {

        $this->log_file = $path;
    }

    // write message to the log file
    public function lwrite($message) {
        // if file pointer doesn't exist, then open log file
        if (!is_resource($this->fp)) {
            $this->lopen();
        }
        // define script name
        $script_name = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME);
        // define current time and suppress E_WARNING if using the system TZ settings
        // (don't forget to set the INI setting date.timezone)
        $time = @date('[d/M/Y:H:i:s]');
        // write current time, script name and message to the log file
        fwrite($this->fp, "$time ($script_name) $message" . PHP_EOL);
    }

    // close log file (it's always a good idea to close a file when you're done with it)
    public function lclose() {
        fclose($this->fp);
    }

    // open log file (private method)
    private function lopen() {
        // in case of Windows set default log file
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $log_file_default = 'D:/logs/vnpaylogs/zencart.txt';
        }
        // set default log file for Linux and other systems
        else {
            $log_file_default = 'D:/logs/vnpaylogs/zencart.txt';
        }
        // define log file from lfile method or use previously set default
        $lfile = $this->log_file ? $this->log_file : $log_file_default;
        // open log file for writing only and place file pointer at the end of the file
        // (if the file does not exist, try to create it)
        $this->fp = fopen($lfile, 'a') or exit("Can't open $lfile!");
    }

    function update_status() {
        global $order, $db;

        if ($this->enabled && (int) MODULE_PAYMENT_COD_ZONE > 0 && isset($order->billing['country']['id'])) {
            $check_flag = false;
            $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_COD_ZONE . "' and zone_country_id = '" . $order->delivery['country']['id'] . "' order by zone_id");
            while (!$check->EOF) {
                if ($check->fields['zone_id'] < 1) {
                    $check_flag = true;
                    break;
                } elseif ($check->fields['zone_id'] == $order->delivery['zone_id']) {
                    $check_flag = true;
                    break;
                }
                $check->MoveNext();
            }

            if ($check_flag == false) {
                $this->enabled = false;
            }
        }

// disable the module if the order only contains virtual products
        if ($this->enabled == true) {
            if ($order->content_type != 'physical') {
                $this->enabled = false;
            }
        }
    }

    function javascript_validation() {
        return false;
    }

    function selection() {
        return array('id' => $this->code,
            'module' => $this->title);
    }

    function pre_confirmation_check() {
       
        if (empty($_SESSION['cart']->cartID)) {
            $_SESSION['cartID'] = $_SESSION['cart']->cartID = $_SESSION['cart']->generate_cart_id();
        }
        if (!$_SESSION['cartID']) {
            $_SESSION['cartID'] = $cartID;
        }
        return false;
    }

    function confirmation() {
 if (file_exists('/logs/vnpaylogs/zencart.txt')) {
            $this->lfile('/logs/vnpaylogs/zencart.txt');
        } else {
            mkdir('/logs/vnpaylogs/', 0777, true);
            touch('/logs/vnpaylogs/zencart.txt');
            $this->lfile('/logs/vnpaydemophp/zencart.txt');
        }
        global $db, $order, $order_total_modules, $insert_id;
        $order_totals1 = $order_total_modules->process();
        //var_dump($order_totals1);
        if ($_SESSION['cartID']) {
            $insert_order = false;

            if ($_SESSION['cart_vnpay_ID']) {
                $order_id = substr($_SESSION['cart_vnpay_ID'], strpos($_SESSION['cart_vnpay_ID'], '-') + 1);

                $curr = $db->Execute("select currency from " . TABLE_ORDERS . " where orders_id = '" . (int) $order_id . "'");

                if (($curr->fields['currency'] != $order->info['currency']) || ($_SESSION['cartID'] != substr($_SESSION['cart_vnpay_ID'], 0, strlen($_SESSION['cartID'])))) {
                    $check_query = $db->Execute('select orders_id from ' . TABLE_ORDERS_STATUS_HISTORY . ' where orders_id = "' . (int) $order_id . '" limit 1');
                    $insert_order = true;
                }
            } else {
                $insert_order = true;
            }

            if ($insert_order == true) {
                $order_totals = array();
                if (is_array($_SESSION['order_total_modules']->modules)) {
                    reset($_SESSION['order_total_modules']->modules);
                    while (list(, $value) = each($_SESSION['order_total_modules']->modules)) {
                        $class = substr($value, 0, strrpos($value, '.'));
                        if ($GLOBALS[$class]->enabled) {
                            for ($i = 0, $n = sizeof($GLOBALS[$class]->output); $i < $n; $i++) {
                                if (zen_not_null($GLOBALS[$class]->output[$i]['title']) && zen_not_null($GLOBALS[$class]->output[$i]['text'])) {
                                    $order_totals[] = array('code' => $GLOBALS[$class]->code,
                                        'title' => $GLOBALS[$class]->output[$i]['title'],
                                        'text' => $GLOBALS[$class]->output[$i]['text'],
                                        'value' => $GLOBALS[$class]->output[$i]['value'],
                                        'sort_order' => $GLOBALS[$class]->sort_order);
                                }
                            }
                        }
                    }
                }

                $sql_data_array = array('customers_id' => $_SESSION['customer_id'],
                    'customers_name' => $order->customer['firstname'] . ' ' . $order->customer['lastname'],
                    'customers_company' => $order->customer['company'],
                    'customers_street_address' => $order->customer['street_address'],
                    'customers_suburb' => $order->customer['suburb'],
                    'customers_city' => $order->customer['city'],
                    'customers_postcode' => $order->customer['postcode'],
                    'customers_state' => $order->customer['state'],
                    'customers_country' => $order->customer['country']['title'],
                    'customers_telephone' => $order->customer['telephone'],
                    'customers_email_address' => $order->customer['email_address'],
                    'customers_address_format_id' => $order->customer['format_id'],
                    'delivery_name' => $order->delivery['firstname'] . ' ' . $order->delivery['lastname'],
                    'delivery_company' => $order->delivery['company'],
                    'delivery_street_address' => $order->delivery['street_address'],
                    'delivery_suburb' => $order->delivery['suburb'],
                    'delivery_city' => $order->delivery['city'],
                    'delivery_postcode' => $order->delivery['postcode'],
                    'delivery_state' => $order->delivery['state'],
                    'delivery_country' => $order->delivery['country']['title'],
                    'delivery_address_format_id' => $order->delivery['format_id'],
                    'billing_name' => $order->billing['firstname'] . ' ' . $order->billing['lastname'],
                    'billing_company' => $order->billing['company'],
                    'billing_street_address' => $order->billing['street_address'],
                    'billing_suburb' => $order->billing['suburb'],
                    'billing_city' => $order->billing['city'],
                    'billing_postcode' => $order->billing['postcode'],
                    'billing_state' => $order->billing['state'],
                    'billing_country' => $order->billing['country']['title'],
                    'billing_address_format_id' => $order->billing['format_id'],
                    'payment_method' => $order->info['payment_method'],
                    'cc_type' => $order->info['cc_type'],
                    'cc_owner' => $order->info['cc_owner'],
                    'cc_number' => $order->info['cc_number'],
                    'cc_expires' => $order->info['cc_expires'],
                    'date_purchased' => 'now()',
                    'orders_status' => $order->info['order_status'],
                    'currency' => $order->info['currency'],
                    'currency_value' => $order->info['currency_value']);
                zen_db_perform(TABLE_ORDERS, $sql_data_array);

                $insert_id = $db->Insert_ID();

                $customer_notification = (SEND_EMAILS == 'true') ? '1' : '0';


                // đã duyệt
                $sql_data_array = array('orders_id' => $insert_id,
                    'orders_status_id' => $order->info['order_status'],
                    'date_added' => 'now()',
                    'customer_notified' => $customer_notification,
                    'comments' => $order->info['comments']);
                zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);

                for ($i = 0, $n = sizeof($order_totals1); $i < $n; $i++) {
                    $sql_data_array = array('orders_id' => $insert_id,
                        'title' => $order_totals1[$i]['title'],
                        'text' => $order_totals1[$i]['text'],
                        'value' => (is_numeric($order_totals1[$i]['value'])) ? $order_totals1[$i]['value'] : '0',
                        'class' => $order_totals1[$i]['code'],
                        'sort_order' => $order_totals1[$i]['sort_order']);

                    zen_db_perform(TABLE_ORDERS_TOTAL, $sql_data_array);
                }
                // đã duyệt
                for ($i = 0, $n = sizeof($order->products); $i < $n; $i++) {
                    $sql_data_array = array('orders_id' => $insert_id,
                        'products_id' => zen_get_prid($order->products[$i]['id']),
                        'products_model' => $order->products[$i]['model'],
                        'products_name' => $order->products[$i]['name'],
                        'products_price' => $order->products[$i]['price'],
                        'final_price' => $order->products[$i]['final_price'],
                        'products_tax' => $order->products[$i]['tax'],
                        'products_quantity' => $order->products[$i]['qty']);

                    zen_db_perform(TABLE_ORDERS_PRODUCTS, $sql_data_array);

                    $order_products_id = $db->Insert_ID();

                    $attributes_exist = '0';
                    if (isset($order->products[$i]['attributes'])) {
                        $attributes_exist = '1';
                        for ($j = 0, $n2 = sizeof($order->products[$i]['attributes']); $j < $n2; $j++) {
                            if (DOWNLOAD_ENABLED == 'true') {
                                $attributes_query = "select popt.products_options_name, poval.products_options_values_name, pa.options_values_price, pa.price_prefix, pad.products_attributes_maxdays, pad.products_attributes_maxcount , pad.products_attributes_filename
								from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " . TABLE_PRODUCTS_ATTRIBUTES . " pa
								left join " . TABLE_PRODUCTS_ATTRIBUTES_DOWNLOAD . " pad
								on pa.products_attributes_id=pad.products_attributes_id
								where pa.products_id = '" . $order->products[$i]['id'] . "'
								and pa.options_id = '" . $order->products[$i]['attributes'][$j]['option_id'] . "'
								and pa.options_id = popt.products_options_id
								and pa.options_values_id = '" . $order->products[$i]['attributes'][$j]['value_id'] . "'
								and pa.options_values_id = poval.products_options_values_id
								and popt.language_id = '" . $_SESSION['languages_id'] . "'
								and poval.language_id = '" . $_SESSION['languages_id'] . "'";
                                $attributes_values = $db->Execute($attributes_query);
                            } else {
                                $attributes_values = $db->Execute("select popt.products_options_name, poval.products_options_values_name, pa.options_values_price, pa.price_prefix from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " . TABLE_PRODUCTS_ATTRIBUTES . " pa where pa.products_id = '" . $order->products[$i]['id'] . "' and pa.options_id = '" . $order->products[$i]['attributes'][$j]['option_id'] . "' and pa.options_id = popt.products_options_id and pa.options_values_id = '" . $order->products[$i]['attributes'][$j]['value_id'] . "' and pa.options_values_id = poval.products_options_values_id and popt.language_id = '" . $_SESSION['languages_id'] . "' and poval.language_id = '" . $_SESSION['languages_id'] . "'");
                            }

                            $sql_data_array = array('orders_id' => $insert_id,
                                'orders_products_id' => $order_products_id,
                                'products_options' => $attributes_values->fields['products_options_name'],
                                'products_options_values' => $attributes_values->fields['products_options_values_name'],
                                'options_values_price' => $attributes_values->fields['options_values_price'],
                                'price_prefix' => $attributes_values->fields['price_prefix']);

                            zen_db_perform(TABLE_ORDERS_PRODUCTS_ATTRIBUTES, $sql_data_array);

                            if ((DOWNLOAD_ENABLED == 'true') && isset($attributes_values->fields['products_attributes_filename']) && zen_not_null($attributes_values->fields['products_attributes_filename'])) {
                                $sql_data_array = array('orders_id' => $insert_id,
                                    'orders_products_id' => $order_products_id,
                                    'orders_products_filename' => $attributes_values->fields['products_attributes_filename'],
                                    'download_maxdays' => $attributes_values->fields['products_attributes_maxdays'],
                                    'download_count' => $attributes_values->fields['products_attributes_maxcount']);

                                zen_db_perform(TABLE_ORDERS_PRODUCTS_DOWNLOAD, $sql_data_array);
                            }
                        }
                    }
                }

                $_SESSION['cart_vnpay_ID'] = $_SESSION['cartID'] . '-' . $insert_id;
            }
        }

        return false;
    }

    function process_button() {
        global $db, $cartID, $cart_vnpay_Standard_ID, $customer_id, $languages_id, $order, $order_total_modules;

        global $charge, $insert_id;
        
        if (file_exists('/logs/vnpaylogs/zencart.txt')) {
            $this->lfile('/logs/vnpaylogs/zencart.txt');
        } else {
            mkdir('/logs/vnpaylogs/', 0777, true);
            touch('/logs/vnpaylogs/zencart.txt');
            $this->lfile('/logs/vnpaydemophp/zencart.txt');
        }
        // echo('<script>alert("khoakd")</script>');
        // $this->lwrite("khoakd đây là sự kiện process button");
        //$orderid = $insert_id;
        $totalamount = $order->info['total'];
        $currentvalue = $order->info['currency_value'];
        $amount = ($totalamount) * $currentvalue; // day chinh la tong tien giao dich
        $this->lwrite("Tổng tiền: " . $amount);
        $date = new DateTime(); //this returns the current date time
        $result = $date->format('Y-m-d-H-i-s');
        $today = date("Y-m-d H:i:s");
        $krr = explode('-', $result);
        $result1 = implode("", $krr);
        $total_amount = $amount;
        $vnp_Url = $this->url_vnpay;
        $vnp_Returnurl = $this->url_return; // trả về link của mình
        //$hashSecret = '';
        $vnp_Locale = "vn";
        $vnp_OrderInfo = 'Thanh toán từ Zencart đơn hàng' . ' Luc :' . $today;
        $vnp_OrderType = "billpayment";
        //$vnp_Merchant = '';
        $vnp_CurrCode = "VND";
        //$vnp_AccessCode = '';
        $vnp_Amount = $total_amount * 100;
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
        $vnp_Merchant = $this->merchantid;
        $this->lwrite($vnp_Merchant);
        $hashSecret = $this->secretkey;
        $this->lwrite($hashSecret);
        $vnp_AccessCode = $this->accesscode;
        $this->lwrite($vnp_AccessCode);
        $Odarray = array(
            "vnp_AccessCode" => $vnp_AccessCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => $result1,
            "vnp_CurrCode" => $vnp_CurrCode,
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_Merchant" => $vnp_Merchant,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $insert_id,
            "vnp_Version" => "1",
        );
        ksort($Odarray);
        $query = "";
        $i = 0;
        $data = "";
        foreach ($Odarray as $key => $value) {
            if ($i == 1) {
                $data .= '&' . $key . "=" . $value;
            } else {
                $data .= $key . "=" . $value;
                $i = 1;
            }

            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }
		$vnp_Url.='?';
        $vnp_Url .=$query;
        if (isset($hashSecret)) {
            $vnpSecureHash = md5($hashSecret . $data);
            $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
            $this->lwrite('========================================================');
            $this->lwrite('HashData=' . $hashSecret . $data);
            $this->lwrite('SecureHash=' . $vnpSecureHash);
            $this->lwrite('RedirectUrl=' . $vnp_Url);
            $this->lwrite('========================================================');
        }
        $js = <<<EOD

        <link href="https://pay.vnpay.vn/lib/vnpbox/vnpbox.css" rel="stylesheet" />
        <script src="https://pay.vnpay.vn/lib/vnpbox/jquery.vnpbox.js"></script>
        <script type="text/javascript">
              $(document).ready(function(){
             jQuery.colorbox({
                                iframe: true,
                                innerWidth: 350,
                                innerHeight: 500, overlayClose: false, scrolling: false,
                                href: "$vnp_Url",
                                onComplete: function () {
                                    var clrobj = $(this).colorbox;
                                    var w = 352;
                                    // Here "addEventListener" is for standards-compliant web browsers and "attachEvent" is for IE Browsers.
                                    var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
                                    var eventer = window[eventMethod];
                                    var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
                                    // Listen to message from child IFrame window
                                    eventer(messageEvent, function (e) {
                                        console.log("e.data = " + e.data);
                                        clrobj.resize({
                                            "height": e.data,
                                            "width": w
                                        });
                                        // Do whatever you want to do with the data got from IFrame in Parent form.
                                    }, false);
                                }
                            });
             return false;
                  });
        </script>
EOD;

        return $js;
    }

    function before_process() {
        $this->after_process();
        // clear cart:
        $_SESSION['cart']->reset(true);
        // redirect to success page
        zen_redirect(zen_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL'));
    }

    function after_process() {
        if (file_exists('/logs/vnpaylogs/zencart.txt')) {
            $this->lfile('/logs/vnpaylogs/zencart.txt');
        } else {
            mkdir('/logs/vnpaylogs/', 0777, true);
            touch('/logs/vnpaylogs/zencart.txt');
            $this->lfile('/logs/vnpaydemophp/zencart.txt');
        }
        $_SESSION['cart']->reset(true);
		unset($_SESSION['sendto']);
		unset($_SESSION['billto']);
		unset($_SESSION['shipping']);
		unset($_SESSION['payment']);
		unset($_SESSION['comments']);
		zen_redirect(zen_href_link(FILENAME_CHECKOUT_SUCCESS, '', 'SSL'));
        //echo "<script type='text/javascript'>alert('after_process');</script>";
        //$this->lwrite("sau khi thực hiện");
        return false;
    }

    function get_error() {
        return false;
    }

    function check() {
        global $db;
        if (!isset($this->_check)) {
            $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_VNPAY_MERCHANT'");
            $this->_check = $check_query->RecordCount();
        }
        return $this->_check;
    }

    function install() {
        global $db, $messageStack;
        if (defined('MODULE_PAYMENT_VNPAY_MERCHANT')) {
            $messageStack->add_session('vnpay module already installed.', 'error');
            zen_redirect(zen_href_link(FILENAME_MODULES, 'set=payment&module=vnpay', 'NONSSL'));
            return 'failed';
        }
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('MERCHANTID', 'MODULE_PAYMENT_VNPAY_MERCHANT', '', 'Merchant Id', '0', 1, 1, now(), NULL, NULL)");
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('The SECRETKEY', 'MODULE_PAYMENT_VNPAY_SECRETKEY', '', 'The SECRETKEY', '0', 1, 1, now(), NULL, NULL)");
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('ACCESSCODE', 'MODULE_PAYMENT_VNPAY_ACCESSCODE', '', 'The ACCESSCODE to vnpayment', '0', 1, 1, now(), NULL, NULL)");
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('URL_VNPAY', 'MODULE_PAYMENT_VNPAY_URL_VNPAY', '', 'URL_VNPAY', '0', 1, 1, now(), NULL, NULL)");
        $db->Execute("INSERT INTO " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('URL_RETURN', 'MODULE_PAYMENT_VNPAY_URL_RETURN', '', 'URL_RETURN', '0', 1, 1, now(), NULL, NULL)");
    }

    function remove() {
        global $db;
        $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
        return array('MODULE_PAYMENT_VNPAY_MERCHANT', 'MODULE_PAYMENT_VNPAY_SECRETKEY', 'MODULE_PAYMENT_VNPAY_ACCESSCODE', 'MODULE_PAYMENT_VNPAY_URL_VNPAY', 'MODULE_PAYMENT_VNPAY_URL_RETURN');
    }

}
