<?php

include(dirname(__FILE__) . '/vnpayment.php');

class VnpaymentValidationModuleFrontController extends ModuleFrontController {

    public function initContent() {
        global $smarty;
        global $cookie;
        $base_dir = $smarty->tpl_vars['base_dir']->value;
        $lang_iso = $smarty->tpl_vars['lang_iso']->value;
        include(dirname(__FILE__) . '/vnpayment.php');
        $vnpayment = new vnpayment();
        $trans_time = date('YmdHis');
        $cart_id = (int) $this->context->cart->id;
        //var_dump($cart_id);
        $order_amount1 = number_format($this->context->cart->getOrderTotal(true, Cart::BOTH), 2, '.', '');
        $order_amount = $order_amount1 * 100;
        $order_currency = $this->context->currency->iso_code;
        if (file_exists('/logs/vnpaylogs/vnplog.txt')) {
            $vnpayment->lfile('/logs/vnpaylogs/vnplog.txt');
        } else {
            mkdir('/logs/vnpaylogs/', 0777, true);
            touch('/logs/vnpaylogs/vnplog.txt');
            $vnpayment->lfile('/logs/vnpaydemophp/vnplog.txt');
        }
        $secret = Configuration::get('VNPAYMENT_SECRET_KEY');
        $order_num = md5($cart_id . $trans_time . $secret) . $cart_id;
        $today = date("Y-m-d H:i:s");
        $vnp_Url = Configuration::get('VNPAYMENT_GATEWAY_URL');
        $vnp_Returnurl = Tools::getShopDomainSsl(true) . _MODULE_DIR_ . 'vnpayment/validation.php?order_currency=' . $order_currency . '&order_num=' . $order_num; //$base_dir . 'module/vnpayment/returnurl?'; //Configuration::get('VNPAYMENT_RETURN_URL');
        $hashSecret = Configuration::get('VNPAYMENT_SECRET_KEY');
        $vnp_Locale = $lang_iso;
        $vnp_OrderInfo = 'Accepts payments by Vnpayment' . ' Luc :' . $today;
        $vnp_OrderType = Configuration::get('VNPAYMENT_TYPES');
        $vnp_Merchant = Configuration::get('VNPAYMENT_MERCHANT_ID');
        $vnp_CurrCode = $order_currency;
        $vnp_AccessCode = Configuration::get('VNPAYMENT_ACCESSCODE');
        $vnp_Amount = $order_amount * 100;
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];
        $Odarray = array(
            "vnp_AccessCode" => $vnp_AccessCode,
            "vnp_Amount" => $vnp_Amount,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => $trans_time,
            "vnp_CurrCode" => $vnp_CurrCode,
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_Merchant" => $vnp_Merchant,
            "vnp_OrderInfo" => $vnp_OrderInfo,
            "vnp_OrderType" => $vnp_OrderType,
            "vnp_ReturnUrl" => $vnp_Returnurl,
            "vnp_TxnRef" => $cart_id,
            "vnp_Version" => "1",
        );
        ksort($Odarray);
        $query = "";
        $i = 0;
        $data = "";
        foreach ($Odarray as $key => $value) {
            if ($i == 1) {
                $data .= '&' . $key . "=" . $value;
            } else {
                $data .= $key . "=" . $value;
                $i = 1;
            }

            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }
	$vnp_Url.='?';
        $vnp_Url .=$query;
        if (isset($hashSecret)) {
            $vnpSecureHash = md5($hashSecret . $data);
            $vnp_Url .= 'vnp_SecureHashType=MD5&vnp_SecureHash=' . $vnpSecureHash;
            $vnpayment->lwrite('========================================================');
            $vnpayment->lwrite('HashData=' . $hashSecret . $data);
            $vnpayment->lwrite('SecureHash=' . $vnpSecureHash);
            $vnpayment->lwrite('RedirectUrl=' . $vnp_Url);
            $vnpayment->lwrite('========================================================');
        }
        $OrdersArray = array('code' => '00'
            , 'message' => 'success'
            , 'data' => $vnp_Url);
        unset($cookie->id_cart);
        echo json_encode($OrdersArray);
        $vnpayment->lclose();
        die;
    }

}
