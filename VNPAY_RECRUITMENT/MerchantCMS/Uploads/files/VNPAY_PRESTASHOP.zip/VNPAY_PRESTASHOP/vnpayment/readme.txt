﻿
/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment cho prestashop            *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp                                          *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */
Bước 1 Download cài đặt prestashop

Bước 2 Download module trên trang  http://vnpayment.vn    

Bước 3 Giải nén file đã download

Bước 4 Copy thư mục vnpayment paste vào thư mục modules trong thư mục gốc của website

Bước 5 vào trang quản trị của website vào menu =>Modules and Services=>Payment tìm đến module vnpayment click install=>Proceed with the installation

Bước 6 click Configure Câp nhật cấu hình đăng ký tại VNPAY

Bước 7 Thành công ra thực hiện thanh toán qua vnpay
