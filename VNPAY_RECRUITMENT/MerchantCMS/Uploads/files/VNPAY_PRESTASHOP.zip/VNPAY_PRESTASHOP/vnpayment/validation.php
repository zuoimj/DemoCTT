<?php

include(dirname(__FILE__) . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/../../header.php');
include(dirname(__FILE__) . '/vnpayment.php');

$vnpayment = new vnpayment();
$vnp_SecureHash = $_GET['vnp_SecureHash'];
$vnp_TxnResponseCode =  $_GET['vnp_ResponseCode'];
$hashSecret = Configuration::get('VNPAYMENT_SECRET_KEY');
$get = $_GET;
$data = array();
foreach ($get as $key => $value) {
    $data[$key] = $value;
}
unset($data["vnp_SecureHashType"]);
unset($data["vnp_SecureHash"]);
unset($data["order_currency"]);
unset($data["order_num"]);
unset($data["controller"]);  
ksort($data);
$i = 0;
$data2 = "";
foreach ($data as $key => $value) {
    if ($i == 1) {
        $data2 .= '&' . $key . "=" . $value;
    } else {
        $data2 .= $key . "=" . $value;
        $i = 1;
    }
}
$secureHash = md5($hashSecret . $data2);
if ($vnpayment->active && $secureHash == $vnp_SecureHash) {
    global $smarty;
    $order_num = Tools::getValue('order_num');
    $cart_id = $vnpayment->getCartId($order_num);
    $cart = new Cart((int) $cart_id);
    if (Validate::isLoadedObject($cart)) {

        $order_currency = Tools::getValue('order_currency');
        $context->cart = $cart;
        $currency = new Currency((int) Currency::getIdByIsoCode(Tools::getValue('orderCurrency')));
        $customer = new Customer((int) $cart->id_customer);
        $context->customer = $customer;
        if ($cart->OrderExists()) {
            Configuration::updateValue('VNPAYMENT_CONFIGURATION_OK', true);
            Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?id_cart=' . (int) $context->cart->id . '&id_module=' . (int) $vnpayment->id . '&id_order=' . (int) $vnpayment->currentOrder . '&key=' . $customer->secure_key);
        } else {
            $total = (float) number_format(Tools::getValue('vnp_Amount') / 100.00, 2, '.', '');
            $order_status = (int) Configuration::get('PS_OS_PAYMENT');
            $vnpayment->validateOrder((int) $cart->id, $order_status, (float) $total, $vnpayment->displayName, NULL, array(), (int) $currency->id, false, $customer->secure_key);
            Configuration::updateValue('VNPAYMENT_CONFIGURATION_OK', true);
            Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?id_cart=' . (int) $context->cart->id . '&id_module=' . (int) $vnpayment->id . '&id_order=' . (int) $vnpayment->currentOrder . '&key=' . $customer->secure_key);
        }
    } else {
        die($vnpayment->l('Invalid Cart ID.'));
    }
} else {
    die($vnpayment->l('VNPAYMENT module is not active.'));
}