
<?php

/* * *************************************************************************
 *                                                                           *
 *            Module tích hợp thanh toán Vnpayment                           *
 * Phiên bản : 1.0                                                           *
 * Module được phát triển bởi VNPAY                                          *
 * Chức năng :                                                               *
 * - Tích hợp thanh toán qua Vnpayment cho các merchant site có đăng ký API. *
 * - Gửi thông tin thanh toán tới Vnpayment để xử lý việc thanh toán.        *
 * @author thangnh@vnpay.vn                                                  *
 * ***************************************************************************
 * Xin hãy đọc kĩ tài liệu tích hợp trên trang                               *
 * http://vnpayment.vn                                                       *
 *                                                                           *
 * *************************************************************************** */

if (!defined('_PS_VERSION_')) {
    exit;
}

class vnpayment extends PaymentModule {

    private $_error = array();
    private $_validation = array();
    private $log_file, $fp;
    private $md5_len = 32;

    // set log file (path and name)
    public function lfile($path) {

        $this->log_file = $path;
    }

    // write message to the log file
    public function lwrite($message) {
        // if file pointer doesn't exist, then open log file
        if (!is_resource($this->fp)) {
            $this->lopen();
        }
        // define script name
        $script_name = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME);
        // define current time and suppress E_WARNING if using the system TZ settings
        // (don't forget to set the INI setting date.timezone)
        $time = @date('[d/M/Y:H:i:s]');
        // write current time, script name and message to the log file
        fwrite($this->fp, "$time ($script_name) $message" . PHP_EOL);
    }

    // close log file (it's always a good idea to close a file when you're done with it)
    public function lclose() {
        fclose($this->fp);
    }

    // open log file (private method)
    private function lopen() {
        // in case of Windows set default log file
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $log_file_default = 'c:/php/logfile.txt';
        }
        // set default log file for Linux and other systems
        else {
            $log_file_default = '/tmp/logfile.txt';
        }
        // define log file from lfile method or use previously set default
        $lfile = $this->log_file ? $this->log_file : $log_file_default;
        // open log file for writing only and place file pointer at the end of the file
        // (if the file does not exist, try to create it)
        $this->fp = fopen($lfile, 'a') or exit("Can't open $lfile!");
    }

    public function __construct() {
        $this->name = 'vnpayment';
        $this->version = '1.0';
        $this->author = 'vnpayment';
        $this->className = 'vnpayment';
        $this->tab = 'payments_gateways';

        parent::__construct();
        $this->page = basename(__FILE__, '.php');
        $this->displayName = $this->l('vnpayment');
        $this->description = $this->l('Accept payments using vnpayment.');
        $this->confirmUninstall = $this->l('Are you sure you want to delete your details?');

        /* Backward compatibility */
        if (version_compare(_PS_VERSION_, '1.5', '<'))
            require_once (_PS_MODULE_DIR_ . 'vnpayment/backward_compatibility/backward.php');

        $this->context->smarty->assign('base_dir', __PS_BASE_URI__);
    }

    public function install() {
        if (!Configuration::get('VNPAYMENT_CURRENCY'))
            Configuration::updateValue('VNPAYMENT_CURRENCY', '');
        if (!Configuration::get('VNPAYMENT_TYPES'))
            Configuration::updateValue('VNPAYMENT_TYPES', '');
        if (!Configuration::get('VNPAYMENT_RETURN_URL'))
            Configuration::updateValue('VNPAYMENT_RETURN_URL', '');
        if (!Configuration::get('VNPAYMENT_ACCESSCODE'))
            Configuration::updateValue('VNPAYMENT_ACCESSCODE', '');
        if (!Configuration::get('VNPAYMENT_GATEWAY_URL'))
            Configuration::updateValue('VNPAYMENT_GATEWAY_URL', '');
        if (!Configuration::get('VNPAYMENT_MERCHANT_ID'))
            Configuration::updateValue('VNPAYMENT_MERCHANT_ID', '');
        if (!Configuration::get('VNPAYMENT_SECRET_KEY'))
            Configuration::updateValue('VNPAYMENT_SECRET_KEY', '');
        return parent::install() && $this->registerHook('payment') && $this->registerHook('orderConfirmation');
    }

    public function uninstall() {
        $keys_to_uninstall = array('VNPAYMENT_GATEWAY_URL', 'VNPAYMENT_MERCHANT_ID','VNPAYMENT_RETURN_URL', 'VNPAYMENT_SECRET_KEY', 'VNPAYMENT_ACCESSCODE', 'VNPAYMENT_CURRENCY', 'VNPAYMENT_TYPES');

        $result = true;
        foreach ($keys_to_uninstall as $key_to_uninstall)
            $result &= Configuration::deleteByName($key_to_uninstall);

        return $result && parent::uninstall();
    }

    public function getContent() {
        if (Tools::isSubmit('SubmitBasicSettings'))
            $this->_saveSettingsBasic();

        if (Configuration::get('VNPAYMENT_GATEWAY_URL') == '' ||
                Configuration::get('VNPAYMENT_MERCHANT_ID') == '' || Configuration::get('VNPAYMENT_SECRET_KEY') == '')
            $this->_warning[] = $this->displayError($this->l('In order to use VNPAYMENT, please provide your API credentials.'));

        if (method_exists('Tools', 'getAdminTokenLite')) {
            $token = Tools::getAdminTokenLite('AdminModules');
        } else {
            $tabid = (int) Tab::getCurrentTabId();
            $employee_id = (int) $this->context->cookie->id_employee;
            $token = 'AdminModules' . $tabid . $employee_id;
            $token = Tools::getAdminToken($token);
        }
        $this->context->smarty->assign(array(
            'vnpayment_form_link' => './index.php?tab=AdminModules&configure=vnpayment&token=' . Tools::getAdminTokenLite('AdminModules') . '&tab_module=' . $this->tab . '&module_name=vnpayment',
            'vnpayment_validation' => (empty($this->_validation) ? false : $this->_validation),
            'vnpayment_error' => (empty($this->_error) ? false : $this->_error),
            'vnpayment_warning' => (empty($this->_warning) ? false : $this->_warning),
            'vnpayment_configuration' => Configuration::getMultiple(array('VNPAYMENT_GATEWAY_URL', 'VNPAYMENT_MERCHANT_ID','VNPAYMENT_RETURN_URL', 'VNPAYMENT_SECRET_KEY', 'VNPAYMENT_ACCESSCODE', 'VNPAYMENT_TYPES', 'VNPAYMENT_CURRENCY')),
        ));

        return $this->display(__FILE__, 'views/templates/admin/configuration.tpl');
    }

    /*
     * VTPayment configuration section - Basic settings (API credentials options)
     */

    private function _saveSettingsBasic() {
        if (!isset($_POST['vnpayment_gateway_url']) || !$_POST['vnpayment_gateway_url'] || !isset($_POST['vnpayment_merchant_id']) || !$_POST['vnpayment_merchant_id'] || !isset($_POST['vnpayment_secret_key']) || !$_POST['vnpayment_secret_key'] || !isset($_POST['vnpayment_accesscode']) || !$_POST['vnpayment_accesscode'] || !isset($_POST['vnpayment_return_url']) || !$_POST['vnpayment_return_url'] || !isset($_POST['vnpayment_types']) || !$_POST['vnpayment_types'] || !isset($_POST['vnpayment_currency']) || !$_POST['vnpayment_currency'])
            $this->_error[] = $this->displayError($this->l('Please fill in all required fields.'));

        Configuration::updateValue('VNPAYMENT_GATEWAY_URL', pSQL(Tools::getValue('vnpayment_gateway_url')));
        Configuration::updateValue('VNPAYMENT_MERCHANT_ID', pSQL(Tools::getValue('vnpayment_merchant_id')));
        Configuration::updateValue('VNPAYMENT_SECRET_KEY', pSQL(Tools::getValue('vnpayment_secret_key')));
        Configuration::updateValue('VNPAYMENT_ACCESSCODE', pSQL(Tools::getValue('vnpayment_accesscode')));
        Configuration::updateValue('VNPAYMENT_RETURN_URL', pSQL(Tools::getValue('vnpayment_return_url')));
        Configuration::updateValue('VNPAYMENT_TYPES', pSQL(Tools::getValue('vnpayment_types')));
        Configuration::updateValue('VNPAYMENT_CURRENCY', pSQL(Tools::getValue('vnpayment_currency')));

        /* TODO: Automated check to verify the API credentials configured by the merchant */

        if (!count($this->_error))
            $this->_validation[] = $this->displayConfirmation($this->l('Congratulations, your configuration was updated successfully'));
    }

    public function hookPayment($params) {
        $html = '';
        $html .= $this->display(__FILE__, 'views/templates/hook/payment.tpl');
        return $html;
    }

    public function hookOrderConfirmation($params) {
      
        if (!isset($params['objOrder']) || ($params['objOrder']->module != $this->name))
            return false;
        if (isset($params['objOrder']) && Validate::isLoadedObject($params['objOrder']) && isset($params['objOrder']->valid) &&
                version_compare(_PS_VERSION_, '1.5', '>=') && isset($params['objOrder']->reference)) {
            $this->smarty->assign('vnpayment_order', array('id' => $params['objOrder']->id, 'reference' => $params['objOrder']->reference, 'valid' => $params['objOrder']->valid, 'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false)));
            return $this->display(__FILE__, 'views/templates/hook/order-confirmation.tpl');
        }

        // 1.4 support
        if (isset($params['objOrder']) && Validate::isLoadedObject($params['objOrder']) && isset($params['objOrder']->valid) &&
                version_compare(_PS_VERSION_, '1.5', '<')) {
            $this->smarty->assign('vnpayment_order', array('id' => $params['objOrder']->id, 'valid' => $params['objOrder']->valid, 'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false)));
            return $this->display(__FILE__, 'views/templates/hook/order-confirmation.tpl');
        }
    }
    public function validateOrderNumber($order_no, $trans_time) {
        $secret = Configuration::get('VNPAYMENT_SECRET_KEY');
        $cart_id = $this->getCartId($order_no);
        $signature = substr($order_no, 0, $this->md5_len);


        if (md5($cart_id . $trans_time . $secret) == $signature)
            return true;
        else
            return false;
    }
    public function getCartId($order_no) {
        return substr($order_no, $this->md5_len, strlen($order_no) - $this->md5_len);
    }

}
